from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import pymysql
import os
from datetime import datetime
import hashlib
import secrets
import socket

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'

# Database configuration
# Auto-detect environment and use appropriate database settings
def is_localhost():
    """Check if the app is running on localhost"""
    try:
        # Get the hostname
        hostname = socket.gethostname()
        # Check if it's localhost or common local development names
        local_indicators = ['localhost', '127.0.0.1', 'DESKTOP', 'LAPTOP', 'MACBOOK', 'kim']
        return any(indicator.lower() in hostname.lower() for indicator in local_indicators)
    except:
        return False

# Database configuration based on environment
if is_localhost():
    # Local development settings
    DB_CONFIG = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'kwetufar_farm',
        'charset': 'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor
    }
    
    # Database configuration without database name for initial connection
    DB_CONFIG_NO_DB = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'charset': 'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor
    }
    
    print("Running in LOCAL development mode")
    print("   Database: localhost (root user)")
else:
    # Production/cPanel settings
    DB_CONFIG = {
        'host': 'localhost',  # cPanel usually uses localhost
        'user': 'kwetufar_farm',
        'password': 'Itskimathi007',
        'database': 'kwetufar_farm',
        'charset': 'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor
    }
    
    # Database configuration without database name for initial connection
    DB_CONFIG_NO_DB = {
        'host': 'localhost',  # cPanel usually uses localhost
        'user': 'kwetufar_farm',
        'password': 'Itskimathi007',
        'charset': 'utf8mb4',
        'cursorclass': pymysql.cursors.DictCursor
    }
    
    print("Running in PRODUCTION mode")
    print("   Database: cPanel (kwetufar_farm user)")

def get_db_connection():
    try:
        # Add timeout and connection settings to prevent lock issues
        connection_config = DB_CONFIG.copy()
        connection_config.update({
            'connect_timeout': 60,
            'read_timeout': 60,
            'write_timeout': 60,
            'autocommit': True  # Enable autocommit to prevent lock issues
        })
        connection = pymysql.connect(**connection_config)
        return connection
    except Exception as e:
        print(f"Database connection error: {str(e)}")
        print(f"Connection details: host={DB_CONFIG['host']}, user={DB_CONFIG['user']}, database={DB_CONFIG['database']}")
        raise e

def get_db_connection_no_db():
    try:
        # Add timeout and connection settings to prevent lock issues
        connection_config = DB_CONFIG_NO_DB.copy()
        connection_config.update({
            'connect_timeout': 60,
            'read_timeout': 60,
            'write_timeout': 60,
            'autocommit': True  # Enable autocommit to prevent lock issues
        })
        connection = pymysql.connect(**connection_config)
        return connection
    except Exception as e:
        print(f"Database connection error (no db): {str(e)}")
        print(f"Connection details: host={DB_CONFIG_NO_DB['host']}, user={DB_CONFIG_NO_DB['user']}")
        raise e

def hash_password(password):
    """Hash password using SHA-256"""
    return hashlib.sha256(password.encode()).hexdigest()

def generate_employee_code():
    """Generate a unique 6-digit employee code"""
    return str(secrets.randbelow(900000) + 100000)

def generate_pig_tag_id(pig_type):
    """Generate a unique tag ID for pigs based on type"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the prefix based on pig type
        prefix_map = {
            'grown_pig': 'P',
            'piglet': 'S', 
            'litter': 'L',
            'batch': 'B'
        }
        prefix = prefix_map.get(pig_type, 'P')
        
        # Get the next available number for this type
        cursor.execute("""
            SELECT MAX(CAST(SUBSTRING(tag_id, 2) AS UNSIGNED)) as max_num 
            FROM pigs 
            WHERE tag_id LIKE %s
        """, (f"{prefix}%",))
        
        result = cursor.fetchone()
        next_num = (result['max_num'] or 0) + 1
        
        # Format as prefix + 3 digits (e.g., P001, S001, etc.)
        tag_id = f"{prefix}{next_num:03d}"
        
        cursor.close()
        conn.close()
        
        return tag_id
        
    except Exception as e:
        print(f"Error generating tag ID: {e}")
        import traceback
        traceback.print_exc()
        # Fallback: start from 001 if database query fails
        return f"{prefix}001"

def generate_litter_id():
    """Generate a unique sequential litter ID (L001, L002, etc.)"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the next available litter number
        cursor.execute("""
            SELECT MAX(CAST(SUBSTRING(litter_id, 2) AS UNSIGNED)) as max_num 
            FROM litters 
            WHERE litter_id LIKE 'L%'
        """)
        
        result = cursor.fetchone()
        next_num = (result['max_num'] or 0) + 1
        
        # Format as L + 3 digits (e.g., L001, L002, etc.)
        litter_id = f"L{next_num:03d}"
        
        # Double-check that this ID doesn't already exist
        cursor.execute("SELECT id FROM litters WHERE litter_id = %s", (litter_id,))
        if cursor.fetchone():
            # If it exists, try the next number
            next_num += 1
            litter_id = f"L{next_num:03d}"
        
        cursor.close()
        conn.close()
        
        print(f"Generated litter ID: {litter_id}")
        return litter_id
        
    except Exception as e:
        print(f"Error generating litter ID: {e}")
        import traceback
        traceback.print_exc()
        # Fallback: start from L001 if database query fails
        return f"L001"

def create_database_and_tables():
    """Create database and tables if they don't exist"""
    try:
        # First, connect without specifying database
        conn = get_db_connection_no_db()
        cursor = conn.cursor()
        
        # Create database if it doesn't exist
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {DB_CONFIG['database']}")
        print(f"Database '{DB_CONFIG['database']}' checked/created successfully")
        
        # Use the database
        cursor.execute(f"USE {DB_CONFIG['database']}")
        
        # Create employees table with updated structure
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                id INT AUTO_INCREMENT PRIMARY KEY,
                full_name VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                phone VARCHAR(20),
                employee_code VARCHAR(6) UNIQUE NOT NULL,
                password VARCHAR(255) NOT NULL,
                profile_image VARCHAR(255),
                role ENUM('administrator', 'manager', 'employee', 'vet', 'it') DEFAULT 'employee',
                status ENUM('waiting_approval', 'active', 'suspended') DEFAULT 'waiting_approval',
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        """)
        print("Employees table checked/created successfully")
        
        # Create activity_log table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS activity_log (
                id INT AUTO_INCREMENT PRIMARY KEY,
                employee_id INT NOT NULL,
                action VARCHAR(100) NOT NULL,
                description TEXT,
                table_name VARCHAR(50),
                record_id INT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees(id)
            )
        """)
        print("Activity log table checked/created successfully")
        
        # Create farms table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS farms (
                id INT AUTO_INCREMENT PRIMARY KEY,
                farm_name VARCHAR(100) UNIQUE NOT NULL,
                farm_location VARCHAR(255) NOT NULL,
                created_by INT NOT NULL,
                status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (created_by) REFERENCES employees(id)
            )
        """)
        print("Farms table checked/created successfully")
        
        # Create pigs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pigs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                tag_id VARCHAR(10) UNIQUE NOT NULL,
                farm_id INT NOT NULL,
                pig_type ENUM('grown_pig', 'piglet', 'litter', 'batch') NOT NULL,
                pig_source ENUM('born', 'purchased') NOT NULL,
                breed VARCHAR(100),
                sex ENUM('male', 'female'),
                purpose ENUM('breeding', 'meat'),
                breeding_status ENUM('young', 'available', 'served', 'pregnant') DEFAULT 'young',
                birth_date DATE,
                purchase_date DATE,
                age_days INT,
                registered_by INT NOT NULL,
                status ENUM('active', 'sold', 'deceased', 'transferred') DEFAULT 'active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (farm_id) REFERENCES farms(id),
                FOREIGN KEY (registered_by) REFERENCES employees(id)
            )
        """)
        print("Pigs table checked/created successfully")
        
        # Check if pig_source column exists, if not add it
        try:
            cursor.execute("SHOW COLUMNS FROM pigs LIKE 'pig_source'")
            if not cursor.fetchone():
                cursor.execute("ALTER TABLE pigs ADD COLUMN pig_source ENUM('born', 'purchased') NOT NULL DEFAULT 'born' AFTER pig_type")
                print("Added pig_source column to pigs table")
        except Exception as e:
                            print(f"Warning: Could not check/add pig_source column: {e}")
        
        # Check if breeding_status column exists, if not add it
        try:
            cursor.execute("SHOW COLUMNS FROM pigs LIKE 'breeding_status'")
            if not cursor.fetchone():
                cursor.execute("ALTER TABLE pigs ADD COLUMN breeding_status ENUM('young', 'available', 'served', 'pregnant') DEFAULT 'young' AFTER purpose")
                print("Added breeding_status column to pigs table")
            else:
                # Check if we need to update the enum values
                cursor.execute("SHOW COLUMNS FROM pigs WHERE Field = 'breeding_status'")
                column_info = cursor.fetchone()
                if column_info and 'farrowed' not in column_info['Type']:
                    # Update the enum to include new values
                    cursor.execute("ALTER TABLE pigs MODIFY COLUMN breeding_status ENUM('young', 'available', 'served', 'pregnant', 'farrowed') DEFAULT 'young'")
                    print("Updated breeding_status enum to include new values")
        except Exception as e:
                            print(f"Warning: Could not check/add breeding_status column: {e}")
        
        # Check if is_edited column exists, if not add it
        try:
            cursor.execute("SHOW COLUMNS FROM pigs LIKE 'is_edited'")
            if not cursor.fetchone():
                cursor.execute("ALTER TABLE pigs ADD COLUMN is_edited BOOLEAN DEFAULT FALSE AFTER updated_at")
                print("Added is_edited column to pigs table")
        except Exception as e:
                            print(f"Warning: Could not check/add is_edited column: {e}")
        
        # Create breeding_records table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS breeding_records (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sow_id INT NOT NULL,
                boar_id INT NOT NULL,
                mating_date DATE NOT NULL,
                expected_due_date DATE,
                status ENUM('served', 'pregnant', 'cancelled', 'completed') DEFAULT 'served',
                notes TEXT,
                created_by INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (sow_id) REFERENCES pigs(id),
                FOREIGN KEY (boar_id) REFERENCES pigs(id),
                FOREIGN KEY (created_by) REFERENCES employees(id)
            )
        """)
        print("Breeding records table checked/created successfully")
        
        # Check and update breeding_records status enum if needed
        try:
            cursor.execute("SHOW COLUMNS FROM breeding_records WHERE Field = 'status'")
            column_info = cursor.fetchone()
            if column_info and 'completed' not in column_info['Type']:
                # Update the enum to include new values
                cursor.execute("ALTER TABLE breeding_records MODIFY COLUMN status ENUM('served', 'pregnant', 'cancelled', 'completed') DEFAULT 'served'")
                print("Updated breeding_records status enum to include 'completed'")
        except Exception as e:
                            print(f"Warning: Could not check/update breeding_records status enum: {e}")

        # Check and add weaning fields to farrowing_activities table if needed
        try:
            cursor.execute("SHOW COLUMNS FROM farrowing_activities WHERE Field = 'weaning_weight'")
            if not cursor.fetchone():
                cursor.execute("ALTER TABLE farrowing_activities ADD COLUMN weaning_weight DECIMAL(5,2) NULL COMMENT 'Weight at weaning (for weaning activity)'")
                print("Added weaning_weight column to farrowing_activities table")
            
            cursor.execute("SHOW COLUMNS FROM farrowing_activities WHERE Field = 'weaning_date'")
            if not cursor.fetchone():
                cursor.execute("ALTER TABLE farrowing_activities ADD COLUMN weaning_date DATETIME NULL COMMENT 'Date and time of weaning (for weaning activity)'")
                print("Added weaning_date column to farrowing_activities table")
        except Exception as e:
                            print(f"Warning: Could not check/add weaning fields to farrowing_activities table: {e}")

        # Check and update litters status enum if needed
        try:
            cursor.execute("SHOW COLUMNS FROM litters WHERE Field = 'status'")
            column_info = cursor.fetchone()
            if column_info and 'unweaned' not in column_info['Type']:
                # First update existing 'active' records to 'unweaned'
                cursor.execute("UPDATE litters SET status = 'unweaned' WHERE status = 'active'")
                print("Updated existing 'active' litter records to 'unweaned'")
                
                # Then update the enum to include 'unweaned' and remove 'active'
                cursor.execute("ALTER TABLE litters MODIFY COLUMN status ENUM('unweaned', 'weaned', 'sold', 'deceased') DEFAULT 'unweaned'")
                print("Updated litters status enum to use 'unweaned' instead of 'active'")
        except Exception as e:
                            print(f"Warning: Could not check/update litters status enum: {e}")
        
        # Create failed_conceptions table to track failed breeding attempts
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS failed_conceptions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sow_id INT NOT NULL,
                boar_id INT NOT NULL,
                mating_date DATE NOT NULL,
                failure_date DATE NOT NULL,
                failure_reason TEXT,
                notes TEXT,
                created_by INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (sow_id) REFERENCES pigs(id),
                FOREIGN KEY (boar_id) REFERENCES pigs(id),
                FOREIGN KEY (created_by) REFERENCES employees(id)
            )
        """)
        print("Failed conceptions table checked/created successfully")
        
        # Create farrowing_records table to track successful farrowings
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS farrowing_records (
                id INT AUTO_INCREMENT PRIMARY KEY,
                breeding_id INT NOT NULL,
                farrowing_date DATE NOT NULL,
                alive_piglets INT NOT NULL,
                still_births INT NOT NULL,
                avg_weight DECIMAL(5,2) NOT NULL,
                health_notes TEXT,
                created_by INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (breeding_id) REFERENCES breeding_records(id),
                FOREIGN KEY (created_by) REFERENCES employees(id)
            )
        """)
        print("Farrowing records table checked/created successfully")
        
        # Create farrowing_activities table to track farrowing activities
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS farrowing_activities (
                id INT AUTO_INCREMENT PRIMARY KEY,
                farrowing_record_id INT NOT NULL,
                activity_name VARCHAR(100) NOT NULL,
                due_day INT NOT NULL,
                due_date DATE NOT NULL,
                completed BOOLEAN DEFAULT FALSE,
                completed_date DATETIME NULL,
                weaning_weight DECIMAL(5,2) NULL,
                weaning_date DATETIME NULL,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (farrowing_record_id) REFERENCES farrowing_records(id)
            )
        """)
        print("Farrowing activities table checked/created successfully")
        
        # Create litters table to track litter information
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS litters (
                id INT AUTO_INCREMENT PRIMARY KEY,
                litter_id VARCHAR(20) UNIQUE NOT NULL,
                farrowing_record_id INT NOT NULL,
                sow_id INT NOT NULL,
                boar_id INT,
                farrowing_date DATE NOT NULL,
                total_piglets INT NOT NULL,
                alive_piglets INT NOT NULL,
                still_births INT DEFAULT 0,
                avg_weight DECIMAL(5,2),
                weaning_weight DECIMAL(5,2),
                weaning_date DATE,
                status ENUM('unweaned', 'weaned', 'sold', 'deceased') DEFAULT 'unweaned',
                notes TEXT,
                created_by INT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (farrowing_record_id) REFERENCES farrowing_records(id),
                FOREIGN KEY (sow_id) REFERENCES pigs(id),
                FOREIGN KEY (boar_id) REFERENCES pigs(id),
                FOREIGN KEY (created_by) REFERENCES employees(id)
            )
        """)
        print("Litters table checked/created successfully")
        
        # Check if sample data exists, if not insert it
        cursor.execute("SELECT COUNT(*) as count FROM employees")
        employee_count = cursor.fetchone()['count']
        
        if employee_count == 0:
            # Insert sample employee data with hashed passwords
            admin_password = hash_password('admin123')
            manager_password = hash_password('manager123')
            employee_password = hash_password('employee123')
            vet_password = hash_password('vet123')
            it_password = hash_password('it123')
            
            cursor.execute("""
                INSERT INTO employees (full_name, email, phone, employee_code, password, role, status) VALUES
                ('John Doe', 'john.doe@farm.com', '+254700000001', '123456', %s, 'administrator', 'active'),
                ('Jane Smith', 'jane.smith@farm.com', '+254700000002', '234567', %s, 'manager', 'active'),
                ('Bob Wilson', 'bob.wilson@farm.com', '+254700000003', '345678', %s, 'employee', 'active'),
                ('Dr. Sarah Johnson', 'sarah.johnson@farm.com', '+254700000004', '456789', %s, 'vet', 'active'),
                ('Mike Tech', 'mike.tech@farm.com', '+254700000005', '567890', %s, 'it', 'active')
            """, (admin_password, manager_password, employee_password, vet_password, it_password))
            print("Sample employee data inserted successfully")
        
        # Create indexes for better performance
        try:
            cursor.execute("CREATE INDEX idx_employees_code ON employees(employee_code)")
            cursor.execute("CREATE INDEX idx_employees_email ON employees(email)")
            cursor.execute("CREATE INDEX idx_employees_status ON employees(status)")
            cursor.execute("CREATE INDEX idx_employees_role ON employees(role)")
            cursor.execute("CREATE INDEX idx_activity_log_date ON activity_log(created_at)")
            print("Database indexes created successfully")
        except Exception as e:
            # Indexes might already exist, that's okay
            pass
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print("Database setup completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Error setting up database: {str(e)}")
        return False

def log_activity(employee_id, action, description, table_name=None, record_id=None):
    """Log employee activity"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO activity_log (employee_id, action, description, table_name, record_id)
            VALUES (%s, %s, %s, %s, %s)
        """, (employee_id, action, description, table_name, record_id))
        # No need to commit since autocommit is enabled
        cursor.close()
        conn.close()
    except Exception as e:
        print(f"Error logging activity: {e}")
        # Don't raise the error to prevent breaking the main functionality

def update_pig_ages(cursor):
    """Update pig ages and breeding status based on current date"""
    try:
        # Get all pigs with birth dates
        cursor.execute("""
            SELECT id, birth_date, pig_type, purpose, breeding_status 
            FROM pigs 
            WHERE birth_date IS NOT NULL AND status = 'active'
        """)
        pigs = cursor.fetchall()
        
        updated_count = 0
        breeding_status_updates = 0
        
        for pig in pigs:
            try:
                # Calculate current age
                birth_dt = pig['birth_date']
                # Convert to date if it's datetime
                if isinstance(birth_dt, datetime):
                    birth_dt = birth_dt.date()
                current_age = (datetime.now().date() - birth_dt).days
                
                # Update age
                cursor.execute("UPDATE pigs SET age_days = %s WHERE id = %s", (current_age, pig['id']))
                
                # Update breeding status for grown pigs with breeding purpose
                if pig['pig_type'] == 'grown_pig' and pig['purpose'] == 'breeding':
                    new_breeding_status = 'available' if current_age >= 200 else 'young'
                    
                    # Only update if status changed
                    if pig['breeding_status'] != new_breeding_status:
                        cursor.execute("""
                            UPDATE pigs 
                            SET breeding_status = %s 
                            WHERE id = %s
                        """, (new_breeding_status, pig['id']))
                        breeding_status_updates += 1
                
                updated_count += 1
                
            except Exception as pig_error:
                print(f"Error updating pig {pig.get('id', 'unknown')}: {pig_error}")
                continue  # Continue with next pig instead of failing completely
        
        print(f"Updated ages for {updated_count} pigs, {breeding_status_updates} breeding status changes")
        return updated_count
        
    except Exception as e:
        print(f"Error updating pig ages: {e}")
        # Don't raise the error to prevent breaking login
        return 0

def get_role_dashboard_url(role):
    """Get the appropriate dashboard URL based on employee role"""
    role_urls = {
        'administrator': '/admin/dashboard',
        'manager': '/manager/dashboard',
        'employee': '/employee/dashboard',
        'vet': '/vet/dashboard',
        'it': '/it/dashboard'
    }
    return role_urls.get(role, '/employee/dashboard')

@app.route('/')
def landing():
    return render_template('landing.html')

@app.route('/test-db')
def test_database():
    """Test database connection and return status"""
    try:
        # Test connection without database
        conn_no_db = get_db_connection_no_db()
        conn_no_db.close()
        
        # Test connection with database
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Test a simple query
        cursor.execute("SELECT 1 as test")
        result = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        # Determine environment
        environment = "LOCAL" if is_localhost() else "PRODUCTION"
        
        return jsonify({
            'success': True,
            'message': 'Database connection successful',
            'environment': environment,
            'config': {
                'host': DB_CONFIG['host'],
                'user': DB_CONFIG['user'],
                'database': DB_CONFIG['database'],
                'charset': DB_CONFIG['charset']
            },
            'test_result': result
        })
        
    except Exception as e:
        # Determine environment
        environment = "LOCAL" if is_localhost() else "PRODUCTION"
        
        return jsonify({
            'success': False,
            'message': f'Database connection failed: {str(e)}',
            'environment': environment,
            'config': {
                'host': DB_CONFIG['host'],
                'user': DB_CONFIG['user'],
                'database': DB_CONFIG['database'],
                'charset': DB_CONFIG['charset']
            },
            'error': str(e)
        }), 500

@app.route('/employee/login')
def employee_login():
    return render_template('employee_login.html')

@app.route('/employee/signup')
def employee_signup():
    return render_template('employee_signup.html')

@app.route('/employee/dashboard')
def employee_dashboard():
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('employee_dashboard.html', user=user_data)

@app.route('/admin/dashboard')
def admin_dashboard():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_dashboard.html', user=user_data)

@app.route('/manager/dashboard')
def manager_dashboard():
    if 'employee_id' not in session or session.get('employee_role') != 'manager':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('manager_dashboard.html', user=user_data)

@app.route('/vet/dashboard')
def vet_dashboard():
    if 'employee_id' not in session or session.get('employee_role') != 'vet':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('vet_dashboard.html', user=user_data)

@app.route('/it/dashboard')
def it_dashboard():
    if 'employee_id' not in session or session.get('employee_role') != 'it':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('it_dashboard.html', user=user_data)

@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.get_json()
    employee_code = data.get('employee_code')
    password = data.get('password')
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if employee exists and password matches
        hashed_password = hash_password(password)
        sql = "SELECT * FROM employees WHERE employee_code = %s AND password = %s AND is_active = TRUE"
        cursor.execute(sql, (employee_code, hashed_password))
        employee = cursor.fetchone()
        
        if employee:
            # Check if employee status is active
            if employee['status'] != 'active':
                cursor.close()
                conn.close()
                if employee['status'] == 'waiting_approval':
                    return {'success': False, 'message': 'Your account is pending approval. Please contact your administrator.'}
                elif employee['status'] == 'suspended':
                    return {'success': False, 'message': 'Your account has been suspended. Please contact your administrator.'}
                else:
                    return {'success': False, 'message': 'Your account is not active. Please contact your administrator.'}
            
            # Update pig ages on login
            try:
                update_pig_ages(cursor)
                print(f"Updated pig ages for employee {employee['full_name']} login")
            except Exception as age_error:
                print(f"Warning: Could not update pig ages: {age_error}")
                # Don't fail login if age update fails
            
            # Update breeding statuses on login
            try:
                update_breeding_statuses()
                print(f"✅ Updated breeding statuses for employee {employee['full_name']} login")
            except Exception as breeding_error:
                print(f"Warning: Could not update breeding statuses: {breeding_error}")
                # Don't fail login if breeding update fails
            
            cursor.close()
            conn.close()
            
            session['employee_id'] = employee['id']
            session['employee_name'] = employee['full_name']
            session['employee_role'] = employee['role']
            session['employee_status'] = employee['status']
            
            # Log login activity
            log_activity(employee['id'], 'LOGIN', f'Employee {employee["full_name"]} logged in successfully')
            
            # Get appropriate dashboard URL based on role
            dashboard_url = get_role_dashboard_url(employee['role'])
            
            return {'success': True, 'redirect': dashboard_url}
        else:
            cursor.close()
            conn.close()
            return {'success': False, 'message': 'Invalid employee code or password'}
            
    except Exception as e:
        return {'success': False, 'message': 'Database error'}

@app.route('/api/check-employee-code', methods=['POST'])
def api_check_employee_code():
    data = request.get_json()
    employee_code = data.get('employee_code')
    
    if not employee_code:
        return {'success': False, 'message': 'Employee code is required'}
    
    if len(employee_code) != 6 or not employee_code.isdigit():
        return {'success': False, 'message': 'Employee code must be exactly 6 digits'}
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if employee code already exists
        cursor.execute("SELECT id FROM employees WHERE employee_code = %s", (employee_code,))
        existing_employee = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if existing_employee:
            return {'success': False, 'message': 'Employee code already registered'}
        else:
            return {'success': True, 'message': 'Employee code is available'}
            
    except Exception as e:
        print(f"Database error in check-employee-code: {str(e)}")
        return {'success': False, 'message': 'Database error'}

@app.route('/api/signup', methods=['POST'])
def api_signup():
    data = request.get_json()
    full_name = data.get('full_name')
    email = data.get('email')
    phone = data.get('phone')
    employee_code = data.get('employee_code')
    password = data.get('password')
    confirm_password = data.get('confirm_password')
    
    # Validation
    if not all([full_name, email, phone, employee_code, password, confirm_password]):
        return {'success': False, 'message': 'All fields are required'}
    
    if len(employee_code) != 6 or not employee_code.isdigit():
        return {'success': False, 'message': 'Employee code must be exactly 6 digits'}
    
    if password != confirm_password:
        return {'success': False, 'message': 'Passwords do not match'}
    
    if len(password) < 6:
        return {'success': False, 'message': 'Password must be at least 6 characters long'}
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if email already exists
        cursor.execute("SELECT id FROM employees WHERE email = %s", (email,))
        if cursor.fetchone():
            return {'success': False, 'message': 'Email already registered'}
        
        # Check if employee code already exists
        cursor.execute("SELECT id FROM employees WHERE employee_code = %s", (employee_code,))
        if cursor.fetchone():
            return {'success': False, 'message': 'Employee code already registered'}
        
        # Hash password and insert new employee with waiting_approval status
        hashed_password = hash_password(password)
        cursor.execute("""
            INSERT INTO employees (full_name, email, phone, employee_code, password, role, status)
            VALUES (%s, %s, %s, %s, %s, 'employee', 'waiting_approval')
        """, (full_name, email, phone, employee_code, hashed_password))
        
        employee_id = cursor.lastrowid
        
        # Log signup activity
        log_activity(employee_id, 'SIGNUP', f'New employee {full_name} registered with code {employee_code} - Status: Waiting Approval')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return {
            'success': True, 
            'message': f'Account created successfully! Your account is pending approval from an administrator.',
            'employee_code': employee_code
        }
        
    except Exception as e:
        print(f"Database error in signup: {str(e)}")
        return {'success': False, 'message': 'Registration failed. Please try again.'}

# Profile and Settings Routes
@app.route('/profile')
def profile():
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('profile.html', user=user_data)

@app.route('/settings')
def settings():
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('settings.html', user=user_data)

@app.route('/app-settings')
def app_settings():
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('app_settings.html', user=user_data)

# Admin Management Routes
@app.route('/admin/role-view')
def admin_role_view():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_role_view.html', user=user_data)

@app.route('/admin/human-resource')
def admin_human_resource():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_human_resource.html', user=user_data)

@app.route('/admin/farm-management')
def admin_farm_management():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_management.html', user=user_data)

@app.route('/admin/analytics')
def admin_analytics():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_analytics.html', user=user_data)

# Farm Management Routes
@app.route('/admin/farm/register')
def admin_farm_register():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_register.html', user=user_data)

@app.route('/admin/farm/view/<int:farm_id>')
def admin_farm_view(farm_id):
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_view.html', user=user_data, farm_id=farm_id)

@app.route('/admin/farm/register-pigs')
def admin_farm_register_pigs():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_register_pigs.html', user=user_data)

@app.route('/admin/farm/pig-management')
def admin_farm_pig_management():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_pig_management.html', user=user_data)

@app.route('/admin/farm/breeding-management')
def admin_farm_breeding_management():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_breeding_management.html', user=user_data)

@app.route('/admin/farm/health-management')
def admin_farm_health_management():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_health_management.html', user=user_data)

@app.route('/admin/farm/location')
def admin_farm_location():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_location.html', user=user_data)

@app.route('/admin/farm/slaughter')
def admin_farm_slaughter():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_slaughter.html', user=user_data)

@app.route('/admin/farm/feeding-management')
def admin_farm_feeding_management():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_feeding_management.html', user=user_data)

@app.route('/admin/farm/health-status')
def admin_farm_health_status():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_health_status.html', user=user_data)

@app.route('/admin/farm/pig-analytics')
def admin_farm_pig_analytics():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get user data from session
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': session['employee_role'],
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('admin_farm_pig_analytics.html', user=user_data)

# Admin Role Access Routes - Allow admin to view role-specific dashboards
@app.route('/admin/access/manager')
def admin_access_manager():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get admin user data but display as manager
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': 'manager',  # Temporarily show as manager
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('manager_dashboard.html', user=user_data)

@app.route('/admin/access/employee')
def admin_access_employee():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get admin user data but display as employee
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': 'employee',  # Temporarily show as employee
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('employee_dashboard.html', user=user_data)

@app.route('/admin/access/vet')
def admin_access_vet():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get admin user data but display as vet
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': 'vet',  # Temporarily show as vet
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('vet_dashboard.html', user=user_data)

@app.route('/admin/access/it')
def admin_access_it():
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return redirect(url_for('employee_login'))
    
    # Get admin user data but display as IT
    user_data = {
        'id': session['employee_id'],
        'name': session['employee_name'],
        'role': 'it',  # Temporarily show as IT
        'status': session['employee_status'],
        'email': f"{session['employee_name'].lower().replace(' ', '.')}@farm.com"
    }
    
    return render_template('it_dashboard.html', user=user_data)

# HR Management API Routes
@app.route('/api/hr/employees', methods=['GET'])
def get_employees():
    """Get all employees for HR management"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, full_name, email, phone, employee_code, role, status, 
                   created_at, profile_image
            FROM employees 
            ORDER BY created_at DESC
        """)
        employees = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'employees': employees})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/hr/approve-employee', methods=['POST'])
def approve_employee():
    """Approve or reject pending employee"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        employee_id = data.get('employee_id')
        action = data.get('action')  # 'approve' or 'reject'
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if action == 'approve':
            cursor.execute("UPDATE employees SET status = 'active' WHERE id = %s", (employee_id,))
            action_desc = 'approved'
        else:
            cursor.execute("DELETE FROM employees WHERE id = %s", (employee_id,))
            action_desc = 'rejected'
        
        conn.commit()
        
        # Log activity
        log_activity(session['employee_id'], 'EMPLOYEE_APPROVAL', 
                    f'Employee {employee_id} {action_desc}')
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': f'Employee {action_desc} successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/hr/update-status', methods=['POST'])
def update_employee_status():
    """Suspend or unsuspend employee"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        employee_id = data.get('employee_id')
        new_status = data.get('status')  # 'active' or 'suspended'
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("UPDATE employees SET status = %s WHERE id = %s", (new_status, employee_id))
        conn.commit()
        
        # Log activity
        log_activity(session['employee_id'], 'STATUS_UPDATE', 
                    f'Employee {employee_id} status changed to {new_status}')
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': f'Employee status updated to {new_status}'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/hr/update-employee', methods=['POST'])
def update_employee():
    """Update employee details"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        employee_id = data.get('employee_id')
        full_name = data.get('full_name')
        email = data.get('email')
        phone = data.get('phone')
        role = data.get('role')
        password = data.get('password')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Build update query based on whether password is provided
        if password:
            hashed_password = hash_password(password)
            cursor.execute("""
                UPDATE employees 
                SET full_name = %s, email = %s, phone = %s, role = %s, password = %s 
                WHERE id = %s
            """, (full_name, email, phone, role, hashed_password, employee_id))
            update_message = 'Employee details and password updated successfully'
        else:
            cursor.execute("""
                UPDATE employees 
                SET full_name = %s, email = %s, phone = %s, role = %s 
                WHERE id = %s
            """, (full_name, email, phone, role, employee_id))
            update_message = 'Employee details updated successfully'
        
        conn.commit()
        
        # Log activity
        log_activity(session['employee_id'], 'EMPLOYEE_UPDATE', 
                    f'Employee {employee_id} details updated')
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': update_message})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/hr/update-permissions', methods=['POST'])
def update_permissions():
    """Update employee permissions"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        employee_id = data.get('employee_id')
        permissions = data.get('permissions', {})
        
        # For now, we'll store permissions as JSON in a comment field
        # In a real system, you'd have a separate permissions table
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Log activity
        log_activity(session['employee_id'], 'PERMISSION_UPDATE', 
                    f'Employee {employee_id} permissions updated')
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Permissions updated successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/hr/update-finance', methods=['POST'])
def update_finance():
    """Update employee finance details"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        employee_id = data.get('employee_id')
        salary = data.get('salary')
        bank_account = data.get('bank_account')
        payment_method = data.get('payment_method')
        
        # For now, we'll log this activity
        # In a real system, you'd have a separate finance table
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Log activity
        log_activity(session['employee_id'], 'FINANCE_UPDATE', 
                    f'Employee {employee_id} finance details updated')
        
        cursor.close()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Finance details updated successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Farm Management API Routes
@app.route('/api/farm/register', methods=['POST'])
def register_farm():
    """Register a new farm"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        farm_name = data.get('farm_name')
        farm_location = data.get('farm_location')
        
        # Validation
        if not farm_name or not farm_location:
            return jsonify({'success': False, 'message': 'Farm name and location are required'})
        
        if len(farm_name.strip()) < 2:
            return jsonify({'success': False, 'message': 'Farm name must be at least 2 characters long'})
        
        if len(farm_location.strip()) < 3:
            return jsonify({'success': False, 'message': 'Farm location must be at least 3 characters long'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if farm name already exists
        cursor.execute("SELECT id FROM farms WHERE farm_name = %s", (farm_name.strip(),))
        if cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Farm name already exists'})
        
        # Insert new farm
        cursor.execute("""
            INSERT INTO farms (farm_name, farm_location, created_by, status)
            VALUES (%s, %s, %s, 'active')
        """, (farm_name.strip(), farm_location.strip(), session['employee_id']))
        
        farm_id = cursor.lastrowid
        
        # Log activity
        log_activity(session['employee_id'], 'FARM_REGISTRATION', 
                    f'New farm "{farm_name}" registered at {farm_location}')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True, 
            'message': f'Farm "{farm_name}" registered successfully',
            'farm_id': farm_id
        })
        
    except Exception as e:
        print(f"Farm registration error: {str(e)}")
        return jsonify({'success': False, 'message': 'Failed to register farm. Please try again.'})

@app.route('/api/farm/statistics', methods=['GET'])
def get_farm_statistics():
    """Get farm statistics for dashboard"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get total farms
        cursor.execute("SELECT COUNT(*) as total_farms FROM farms WHERE status = 'active'")
        total_farms = cursor.fetchone()['total_farms']
        
        # Get total pigs
        cursor.execute("SELECT COUNT(*) as total_pigs FROM pigs WHERE status = 'active'")
        total_pigs = cursor.fetchone()['total_pigs']
        
        # Get growth rate (placeholder - will be calculated based on pig growth data)
        growth_rate = "0%"  # Placeholder for now
        
        # Get health issues (placeholder - will be updated when health records table is created)
        health_issues = 0  # Placeholder for now
        
        # Get breeding statistics
        cursor.execute("SELECT COUNT(*) as total_breeding FROM breeding_records WHERE status = 'served' OR status = 'pregnant'")
        total_breeding = cursor.fetchone()['total_breeding']
        
        cursor.execute("SELECT COUNT(*) as total_failed FROM failed_conceptions")
        total_failed = cursor.fetchone()['total_failed']
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'statistics': {
                'total_farms': total_farms,
                'total_pigs': total_pigs,
                'growth_rate': growth_rate,
                'health_issues': health_issues,
                'total_breeding': total_breeding,
                'total_failed': total_failed
            }
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/farm/list', methods=['GET'])
def get_farms_list():
    """Get all farms for display"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all farms with creator information
        cursor.execute("""
            SELECT f.*, e.full_name as created_by_name 
            FROM farms f 
            LEFT JOIN employees e ON f.created_by = e.id 
            WHERE f.status = 'active'
            ORDER BY f.created_at DESC
        """)
        farms = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'farms': farms
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/farm/details/<int:farm_id>', methods=['GET'])
def get_farm_details(farm_id):
    """Get specific farm details"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get farm details with creator information
        cursor.execute("""
            SELECT f.*, e.full_name as created_by_name 
            FROM farms f 
            LEFT JOIN employees e ON f.created_by = e.id 
            WHERE f.id = %s AND f.status = 'active'
        """, (farm_id,))
        farm = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not farm:
            return jsonify({'error': 'Farm not found'}), 404
        
        return jsonify({
            'success': True,
            'farm': farm
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/farm/pigs/<int:farm_id>', methods=['GET'])
def get_farm_pigs(farm_id):
    """Get all pigs registered to a specific farm"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all pigs for the specific farm
        cursor.execute("""
            SELECT p.id, p.tag_id, p.farm_id, p.pig_type, p.pig_source, p.breed, p.sex, 
                   p.purpose, p.breeding_status, p.birth_date, p.purchase_date, p.age_days,
                   p.registered_by, p.status, p.created_at, p.updated_at, f.farm_name 
            FROM pigs p 
            LEFT JOIN farms f ON p.farm_id = f.id 
            WHERE p.farm_id = %s AND p.status = 'active'
            ORDER BY p.created_at DESC
        """, (farm_id,))
        pigs = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'pigs': pigs
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/farm/litters/<int:farm_id>', methods=['GET'])
def get_farm_litters(farm_id):
    """Get all litters for a specific farm"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all litters for the specific farm with sow information
        cursor.execute("""
            SELECT l.id, l.litter_id, l.farrowing_record_id, l.sow_id, l.boar_id,
                   l.total_piglets, l.alive_piglets, l.still_births,
                   l.avg_weight, l.weaning_weight, l.weaning_date, l.farrowing_date,
                   l.status, l.created_at, l.updated_at,
                   p.tag_id as sow_tag, p.breed as sow_breed,
                   f.farm_name
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            LEFT JOIN farms f ON p.farm_id = f.id
            WHERE p.farm_id = %s AND l.status IN ('unweaned', 'weaned')
            ORDER BY l.created_at DESC
        """, (farm_id,))
        litters = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'litters': litters
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Pig Management API Routes
@app.route('/api/pig/register', methods=['POST'])
def register_pig():
    """Register a new pig"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        farm_id = data.get('farm_id')
        pig_type = data.get('pig_type')
        pig_source = data.get('pig_source')
        breed = data.get('breed')
        sex = data.get('sex')
        purpose = data.get('purpose')
        birth_date = data.get('birth_date')
        purchase_date = data.get('purchase_date')
        
        # Validation
        if not farm_id or not pig_type or not pig_source:
            return jsonify({'success': False, 'message': 'Farm, pig type, and pig source are required'})
        
        if pig_type not in ['grown_pig', 'piglet', 'litter', 'batch']:
            return jsonify({'success': False, 'message': 'Invalid pig type'})
        
        if pig_source not in ['born', 'purchased']:
            return jsonify({'success': False, 'message': 'Invalid pig source'})
        
        # Validate date requirements based on pig source
        if not birth_date:
            return jsonify({'success': False, 'message': 'Birth date is required for all pigs'})
        
        if pig_source == 'purchased' and not purchase_date:
            return jsonify({'success': False, 'message': 'Purchase date is required for purchased pigs'})
        
        # For grown pigs, breed, sex, and purpose are required
        if pig_type == 'grown_pig':
            if not breed or not sex or not purpose:
                return jsonify({'success': False, 'message': 'Breed, sex, and purpose are required for grown pigs'})
        
        # Calculate age in days if birth date is provided
        age_days = None
        if birth_date:
            try:
                birth_dt = datetime.strptime(birth_date, '%Y-%m-%d')
                age_days = (datetime.now() - birth_dt).days
            except ValueError:
                return jsonify({'success': False, 'message': 'Invalid birth date format'})
        
        # Determine breeding status for grown pigs based on age
        breeding_status = None
        if pig_type == 'grown_pig' and purpose == 'breeding' and age_days is not None:
            breeding_status = 'available' if age_days >= 200 else 'young'
        elif pig_type == 'grown_pig' and purpose == 'meat':
            breeding_status = None  # Meat pigs don't have breeding status
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if farm exists
        cursor.execute("SELECT id FROM farms WHERE id = %s AND status = 'active'", (farm_id,))
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Farm not found or inactive'})
        
        # Generate unique tag ID
        tag_id = generate_pig_tag_id(pig_type)
        
        # Insert new pig
        cursor.execute("""
            INSERT INTO pigs (tag_id, farm_id, pig_type, pig_source, breed, sex, purpose, breeding_status, birth_date, purchase_date, age_days, registered_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (tag_id, farm_id, pig_type, pig_source, breed, sex, purpose, breeding_status, birth_date, purchase_date, age_days, session['employee_id']))
        
        pig_id = cursor.lastrowid
        
        # Log activity
        log_activity(session['employee_id'], 'PIG_REGISTRATION', 
                    f'New {pig_type} registered with tag {tag_id} at farm {farm_id}')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True, 
            'message': f'Pig registered successfully with tag {tag_id}',
            'pig_id': pig_id,
            'tag_id': tag_id
        })
        
    except Exception as e:
        print(f"Pig registration error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'Failed to register pig: {str(e)}'})

@app.route('/api/pig/list', methods=['GET'])
def get_pigs_list():
    """Get all pigs for display"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all pigs with farm and registration information
        cursor.execute("""
            SELECT p.*, f.farm_name, e.full_name as registered_by_name 
            FROM pigs p 
            LEFT JOIN farms f ON p.farm_id = f.id 
            LEFT JOIN employees e ON p.registered_by = e.id 
            WHERE p.status = 'active'
            ORDER BY p.created_at DESC
        """)
        pigs = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'pigs': pigs
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/pig/generate-tag-id', methods=['POST'])
def generate_tag_id():
    """Generate a new tag ID for a pig type"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        pig_type = data.get('pig_type')
        
        if not pig_type or pig_type not in ['grown_pig', 'piglet', 'litter', 'batch']:
            return jsonify({'success': False, 'message': 'Invalid pig type'})
        
        # Generate the tag ID
        tag_id = generate_pig_tag_id(pig_type)
        
        return jsonify({
            'success': True,
            'tag_id': tag_id
        })
        
    except Exception as e:
        print(f"Tag ID generation error: {str(e)}")
        return jsonify({'success': False, 'message': 'Failed to generate tag ID'})

@app.route('/api/pig/update/<int:pig_id>', methods=['PUT'])
def update_pig(pig_id):
    """Update pig details"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        
        # Get current pig data for comparison
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM pigs WHERE id = %s
        """, (pig_id,))
        
        current_pig = cursor.fetchone()
        if not current_pig:
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Pig not found'})
        
        # Prepare update data
        update_fields = []
        update_values = []
        changes = []
        
        # Check each field for changes
        fields_to_check = {
            'farm_id': 'Farm',
            'pig_type': 'Pig Type',
            'pig_source': 'Pig Source',
            'breed': 'Breed',
            'sex': 'Sex',
            'purpose': 'Purpose',
            'birth_date': 'Birth Date',
            'purchase_date': 'Purchase Date',
            'status': 'Status'
        }
        
        # Special handling for tag ID changes
        tag_id_changed = False
        new_tag_id = None
        if 'tag_id' in data and data['tag_id'] != current_pig['tag_id']:
            new_tag_id = data['tag_id']
            tag_id_changed = True
            changes.append(f"Tag ID: {current_pig['tag_id']} → {new_tag_id}")
        
        for field, display_name in fields_to_check.items():
            if field in data and data[field] != current_pig[field]:
                if data[field] is not None:
                    update_fields.append(f"{field} = %s")
                    update_values.append(data[field])
                    old_value = current_pig[field] if current_pig[field] is not None else 'None'
                    new_value = data[field]
                    changes.append(f"{display_name}: {old_value} → {new_value}")
                else:
                    update_fields.append(f"{field} = NULL")
                    old_value = current_pig[field] if current_pig[field] is not None else 'None'
                    changes.append(f"{display_name}: {old_value} → None")
        
        if not update_fields and not tag_id_changed:
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'No changes detected'})
        
        # Update age_days if birth_date changed
        if 'birth_date' in data and data['birth_date'] != current_pig['birth_date']:
            if data['birth_date']:
                try:
                    birth_dt = datetime.strptime(data['birth_date'], '%Y-%m-%d').date()
                    age_days = (datetime.now().date() - birth_dt).days
                    update_fields.append("age_days = %s")
                    update_values.append(age_days)
                    changes.append(f"Age: {current_pig['age_days'] or 'Unknown'} days → {age_days} days")
                except ValueError:
                    cursor.close()
                    conn.close()
                    return jsonify({'success': False, 'message': 'Invalid birth date format'})
        
        # Always recalculate age_days for all pigs to ensure accuracy
        if 'birth_date' in data:
            try:
                birth_dt = datetime.strptime(data['birth_date'], '%Y-%m-%d').date()
                age_days = (datetime.now().date() - birth_dt).days
                update_fields.append("age_days = %s")
                update_values.append(age_days)
                if 'birth_date' not in [f.split(' = ')[0] for f in update_fields if 'birth_date' in f]:
                    changes.append(f"Age recalculated: {age_days} days")
            except ValueError:
                cursor.close()
                conn.close()
                return jsonify({'success': False, 'message': 'Invalid birth date format'})
        
        # Add updated_at timestamp
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        
        # Execute update
        if update_fields:
            update_query = f"UPDATE pigs SET {', '.join(update_fields)} WHERE id = %s"
            update_values.append(pig_id)
            cursor.execute(update_query, update_values)
        
        # Handle tag ID change separately (if changed)
        if tag_id_changed:
            # Add "E" prefix to show the pig has been edited
            edited_tag_id = f"E{new_tag_id}"
            cursor.execute("""
                UPDATE pigs SET tag_id = %s WHERE id = %s
            """, (edited_tag_id, pig_id))
            changes.append(f"Tag ID: {current_pig['tag_id']} → {edited_tag_id} (edited)")
        
        # Handle status changes with reason
        status_reason = data.get('status_reason')
        if 'status' in data and data['status'] != current_pig['status']:
            old_status = current_pig['status']
            new_status = data['status']
            
            if status_reason:
                changes.append(f"Status: {old_status} → {new_status} (Reason: {status_reason})")
                # Log status change with reason
                log_activity(session['employee_id'], 'PIG_STATUS_CHANGE', 
                           f'Changed pig {current_pig["tag_id"]} status from {old_status} to {new_status}. Reason: {status_reason}')
            else:
                changes.append(f"Status: {old_status} → {new_status}")
                # Log status change without reason
                log_activity(session['employee_id'], 'PIG_STATUS_CHANGE', 
                           f'Changed pig {current_pig["tag_id"]} status from {old_status} to {new_status}')
        
        # Mark pig as edited in the database
        cursor.execute("""
            UPDATE pigs SET is_edited = 1 WHERE id = %s
        """, (pig_id,))
        
        # Log activity
        log_activity(session['employee_id'], 'PIG_UPDATE', 
                    f'Updated pig {current_pig["tag_id"]} with changes: {", ".join(changes)}')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Pig updated successfully',
            'changes': changes
        })
        
    except Exception as e:
        print(f"Error updating pig: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'Failed to update pig: {str(e)}'})

@app.route('/api/pig/details/<int:pig_id>', methods=['GET'])
def get_pig_details(pig_id):
    """Get specific pig details for editing"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get pig details with farm information
        cursor.execute("""
            SELECT p.*, f.farm_name 
            FROM pigs p 
            LEFT JOIN farms f ON p.farm_id = f.id 
            WHERE p.id = %s
        """, (pig_id,))
        
        pig = cursor.fetchone()
        if not pig:
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Pig not found'})
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'pig': pig
        })
        
    except Exception as e:
        print(f"Error getting pig details: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get pig details: {str(e)}'})

@app.route('/api/pig/validate-tag-id', methods=['POST'])
def validate_pig_tag_id():
    """Validate pig tag ID and check for duplicates"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        tag_id = data.get('tag_id')
        current_pig_id = data.get('current_pig_id')  # To exclude current pig from duplicate check
        
        if not tag_id:
            return jsonify({'success': False, 'message': 'Tag ID is required'})
        
        # Validate tag ID format (letter + numbers)
        if not tag_id[0].isalpha() or not tag_id[1:].isdigit():
            return jsonify({'success': False, 'message': 'Tag ID must start with a letter followed by numbers'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check for duplicates (excluding current pig if editing)
        if current_pig_id:
            cursor.execute("""
                SELECT id FROM pigs WHERE tag_id = %s AND id != %s
            """, (tag_id, current_pig_id))
        else:
            cursor.execute("""
                SELECT id FROM pigs WHERE tag_id = %s
            """, (tag_id,))
        
        existing_pig = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if existing_pig:
            return jsonify({
                'success': False, 
                'message': f'Tag ID "{tag_id}" already exists. Please choose a different one.'
            })
        
        return jsonify({
            'success': True,
            'message': f'Tag ID "{tag_id}" is available'
        })
        
    except Exception as e:
        print(f"Error validating tag ID: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to validate tag ID: {str(e)}'})

@app.route('/api/pig/recalculate-ages', methods=['POST'])
def recalculate_pig_ages():
    """Recalculate ages for all pigs based on birth dates"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all pigs with birth dates
        cursor.execute("""
            SELECT id, birth_date, age_days FROM pigs 
            WHERE birth_date IS NOT NULL AND status = 'active'
        """)
        pigs = cursor.fetchall()
        
        updated_count = 0
        for pig in pigs:
            if pig['birth_date']:
                try:
                    birth_dt = datetime.strptime(str(pig['birth_date']), '%Y-%m-%d').date()
                    age_days = (datetime.now().date() - birth_dt).days
                    
                    # Update age if it's different
                    if pig['age_days'] != age_days:
                        cursor.execute("""
                            UPDATE pigs SET age_days = %s WHERE id = %s
                        """, (age_days, pig['id']))
                        updated_count += 1
                        
                except ValueError:
                    continue  # Skip invalid dates
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Updated ages for {updated_count} pigs'
        })
        
    except Exception as e:
        print(f"Error recalculating pig ages: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to recalculate ages: {str(e)}'})

@app.route('/api/pig/audit-trail/<int:pig_id>', methods=['GET'])
def get_pig_audit_trail(pig_id):
    """Get audit trail for a specific pig"""
    if 'employee_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get pig basic info
        cursor.execute("""
            SELECT p.*, f.farm_name 
            FROM pigs p 
            LEFT JOIN farms f ON p.farm_id = f.id 
            WHERE p.id = %s
        """, (pig_id,))
        pig = cursor.fetchone()
        
        if not pig:
            return jsonify({'success': False, 'message': 'Pig not found'}), 404
        
        # Get activity log entries for this pig
        cursor.execute("""
            SELECT al.*, e.full_name, e.role
            FROM activity_log al
            LEFT JOIN employees e ON al.employee_id = e.id
            WHERE al.action IN ('PIG_REGISTRATION', 'PIG_UPDATE', 'PIG_STATUS_CHANGE', 'BREEDING_REGISTRATION', 'BREEDING_CANCELLATION', 'FARROWING_ACTIVITY_COMPLETED', 'BREEDING_CYCLE_COMPLETED', 'LITTER_REGISTRATION', 'LITTER_POSTPONED', 'LOGIN', 'LOGOUT')
            AND al.description LIKE %s
            ORDER BY al.created_at DESC
        """, (f'%{pig["tag_id"]}%',))
        
        audit_entries = cursor.fetchall()
        
        # Format audit entries
        formatted_entries = []
        for entry in audit_entries:
            formatted_entries.append({
                'timestamp': entry['created_at'].strftime('%Y-%m-%d %H:%M:%S') if entry['created_at'] else 'Unknown',
                'activity_type': entry['action'],
                'description': entry['description'],
                'employee_name': entry['full_name'] or 'Unknown',
                'employee_role': entry['role'] or 'Unknown'
            })
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'pig': pig,
            'audit_trail': formatted_entries
        })
        
    except Exception as e:
        print(f"Error getting pig audit trail: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get audit trail: {str(e)}'})

@app.route('/api/pigs/sows', methods=['GET'])
def get_sows():
    """Get all sows (female pigs) for breeding"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all sows (female pigs with breeding purpose)
        cursor.execute("""
            SELECT p.id, p.tag_id, p.breed, p.farm_id, f.farm_name
            FROM pigs p
            LEFT JOIN farms f ON p.farm_id = f.id
            WHERE p.sex = 'female' 
            AND p.purpose = 'breeding'
            AND p.status = 'active'
            ORDER BY p.tag_id
        """)
        
        sows = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'sows': sows
        })
        
    except Exception as e:
        print(f"Error getting sows: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get sows: {str(e)}'})

# Litter Management API Endpoints

@app.route('/api/litter/next-id', methods=['GET'])
def get_next_litter_id():
    """Get next available litter ID"""
    if 'employee_id' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get the highest existing litter ID
        cursor.execute("""
            SELECT litter_id FROM litters 
            ORDER BY CAST(SUBSTRING(litter_id, 2) AS UNSIGNED) DESC 
            LIMIT 1
        """)
        
        result = cursor.fetchone()
        
        if result:
            # Extract number from existing ID (e.g., L001 -> 1)
            current_number = int(result['litter_id'][1:])
            next_number = current_number + 1
        else:
            # No existing litters, start with 1
            next_number = 1
        
        # Format as L001, L002, etc.
        next_litter_id = f"L{next_number:03d}"
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'next_litter_id': next_litter_id
        })
        
    except Exception as e:
        print(f"Error getting next litter ID: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get next litter ID: {str(e)}'})

@app.route('/api/litter/register', methods=['POST'])
def register_litter():
    """Register a new litter"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['sow_id', 'farrowing_record_id', 'litter_id', 'farrowing_date', 'total_piglets', 'alive_piglets']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'success': False, 'message': f'{field.replace("_", " ").title()} is required'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if litter ID already exists
        cursor.execute("SELECT id FROM litters WHERE litter_id = %s", (data['litter_id'],))
        if cursor.fetchone():
            return jsonify({'success': False, 'message': 'Litter ID already exists'})
        
        # Get weaning data from farrowing activities if available
        weaning_weight = None
        weaning_date = None
        
        cursor.execute("""
            SELECT weaning_weight, weaning_date 
            FROM farrowing_activities 
            WHERE farrowing_record_id = %s AND activity_name = 'Weaning' AND completed = TRUE
        """, (data['farrowing_record_id'],))
        
        weaning_data = cursor.fetchone()
        if weaning_data:
            weaning_weight = weaning_data['weaning_weight']
            weaning_date = weaning_data['weaning_date']
        
        # Insert litter record
        cursor.execute("""
            INSERT INTO litters (
                litter_id, farrowing_record_id, sow_id, boar_id, farrowing_date,
                total_piglets, alive_piglets, still_births, avg_weight, 
                weaning_weight, weaning_date, notes, created_by
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            data['litter_id'], data['farrowing_record_id'], data['sow_id'], 
            data.get('boar_id'), data['farrowing_date'], data['total_piglets'],
            data['alive_piglets'], data.get('still_births', 0), data.get('avg_weight'),
            weaning_weight, weaning_date, data.get('notes'), session['employee_id']
        ))
        
        litter_id = cursor.lastrowid
        
        # Get breeding record ID from farrowing record
        cursor.execute("""
            SELECT breeding_id FROM farrowing_records WHERE id = %s
        """, (data['farrowing_record_id'],))
        
        breeding_record = cursor.fetchone()
        if not breeding_record:
            return jsonify({'success': False, 'message': 'Breeding record not found for this farrowing'})
        
        # Update breeding record status to completed
        cursor.execute("""
            UPDATE breeding_records 
            SET status = 'completed', completed_date = %s 
            WHERE id = %s
        """, (data['farrowing_date'], breeding_record['breeding_id']))
        
        # Update sow breeding status back to available
        cursor.execute("""
            UPDATE pigs 
            SET breeding_status = 'available' 
            WHERE id = %s
        """, (data['sow_id']))
        
        # Log activity
        log_activity(session['employee_id'], 'LITTER_REGISTRATION', 
                   f'Registered litter {data["litter_id"]} with {data["alive_piglets"]} alive piglets from sow {data["sow_id"]}')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Litter {data["litter_id"]} registered successfully with {data["alive_piglets"]} alive piglets'
        })
        
    except Exception as e:
        print(f"Error registering litter: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to register litter: {str(e)}'})

@app.route('/api/litter/postpone', methods=['POST'])
def postpone_litter_registration():
    """Postpone litter registration with reason"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        
        if not data.get('reason'):
            return jsonify({'success': False, 'message': 'Reason for postponement is required'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get breeding record ID from farrowing record
        cursor.execute("""
            SELECT breeding_id FROM farrowing_records WHERE id = %s
        """, (data['farrowing_record_id'],))
        
        breeding_record = cursor.fetchone()
        if not breeding_record:
            return jsonify({'success': False, 'message': 'Breeding record not found for this farrowing'})
        
        # Update breeding record status to postponed
        cursor.execute("""
            UPDATE breeding_records 
            SET status = 'postponed', notes = %s 
            WHERE id = %s
        """, (data['reason'], breeding_record['breeding_id']))
        
        # Log activity
        log_activity(session['employee_id'], 'LITTER_POSTPONED', 
                   f'Postponed litter registration for farrowing record {data["farrowing_record_id"]}. Reason: {data["reason"]}')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Litter registration postponed successfully'
        })
        
    except Exception as e:
        print(f"Error postponing litter registration: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to postpone litter registration: {str(e)}'})

# Breeding Management API Endpoints

@app.route('/api/breeding/available-sows', methods=['GET'])
def get_available_sows():
    """Get all sows available for breeding (breeding_status = 'available')"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get sows that are available for breeding
        cursor.execute("""
            SELECT p.id, p.tag_id, p.breed, p.age_days, f.farm_name
            FROM pigs p 
            LEFT JOIN farms f ON p.farm_id = f.id 
            WHERE p.sex = 'female' 
            AND p.pig_type = 'grown_pig' 
            AND p.purpose = 'breeding' 
            AND p.breeding_status = 'available'
            AND p.status = 'active'
            ORDER BY p.tag_id
        """)
        sows = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'sows': sows
        })
        
    except Exception as e:
        print(f"Error getting available sows: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/breeding/completed-cycles', methods=['GET'])
def get_completed_breeding_cycles():
    """Get breeding records that have completed their cycle and need litter registration"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get breeding records that are ready for litter registration
        # This includes records that are past expected farrowing date and still marked as 'pregnant'
        cursor.execute("""
            SELECT br.*, 
                   sow.tag_id as sow_tag_id, sow.breed as sow_breed, sow.age_days as sow_age_days,
                   sow.farm_id as sow_farm_id, f.farm_name as sow_farm_name,
                   boar.tag_id as boar_tag_id
            FROM breeding_records br
            LEFT JOIN pigs sow ON br.sow_id = sow.id
            LEFT JOIN pigs boar ON br.boar_id = boar.id
            LEFT JOIN farms f ON sow.farm_id = f.id
            WHERE br.status = 'pregnant' 
            AND br.expected_farrowing <= CURDATE()
            AND br.expected_farrowing >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
            AND NOT EXISTS (
                SELECT 1 FROM litters l WHERE l.farrowing_record_id = br.id
            )
            ORDER BY br.expected_farrowing ASC
        """)
        
        completed_cycles = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'completed_cycles': completed_cycles
        })
        
    except Exception as e:
        print(f"Error getting completed breeding cycles: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/breeding/available-boars', methods=['GET'])
def get_available_boars():
    """Get all boars available for breeding"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get boars that are available for breeding
        cursor.execute("""
            SELECT p.id, p.tag_id, p.breed, p.age_days, f.farm_name
            FROM pigs p 
            LEFT JOIN farms f ON p.farm_id = f.id 
            WHERE p.sex = 'male' 
            AND p.pig_type = 'grown_pig' 
            AND p.purpose = 'breeding' 
            AND p.status = 'active'
            ORDER BY p.tag_id
        """)
        boars = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'boars': boars
        })
        
    except Exception as e:
        print(f"Error getting available boars: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/breeding/register', methods=['POST'])
def register_breeding():
    """Register a new breeding record"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        sow_id = data.get('sow_id')
        boar_id = data.get('boar_id')
        mating_date = data.get('mating_date')
        notes = data.get('notes', '')
        
        # Validation
        if not all([sow_id, boar_id, mating_date]):
            return jsonify({'success': False, 'message': 'All fields are required'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Verify sow is available for breeding
        cursor.execute("""
            SELECT id, tag_id, breeding_status 
            FROM pigs 
            WHERE id = %s AND sex = 'female' AND pig_type = 'grown_pig' 
            AND purpose = 'breeding' AND breeding_status = 'available' AND status = 'active'
        """, (sow_id,))
        sow = cursor.fetchone()
        
        if not sow:
            return jsonify({'success': False, 'message': 'Selected sow is not available for breeding'})
        
        # Verify boar exists and is male
        cursor.execute("""
            SELECT id, tag_id 
            FROM pigs 
            WHERE id = %s AND sex = 'male' AND pig_type = 'grown_pig' 
            AND purpose = 'breeding' AND status = 'active'
        """, (boar_id,))
        boar = cursor.fetchone()
        
        if not boar:
            return jsonify({'success': False, 'message': 'Selected boar is not valid'})
        
        # Calculate expected due date (114 days from mating)
        from datetime import datetime, timedelta
        mating_dt = datetime.strptime(mating_date, '%Y-%m-%d')
        expected_due_date = mating_dt + timedelta(days=114)
        
        # Insert breeding record
        cursor.execute("""
            INSERT INTO breeding_records (sow_id, boar_id, mating_date, expected_due_date, notes, created_by)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (sow_id, boar_id, mating_date, expected_due_date.date(), notes, session['employee_id']))
        
        breeding_id = cursor.lastrowid
        
        # Update sow's breeding status to 'served'
        cursor.execute("""
            UPDATE pigs 
            SET breeding_status = 'served' 
            WHERE id = %s
        """, (sow_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        # Log activity
        log_activity(session['employee_id'], 'BREEDING_REGISTRATION', 
                    f'Breeding record created: Sow {sow["tag_id"]} with Boar {boar["tag_id"]}')
        
        return jsonify({
            'success': True,
            'message': 'Breeding record registered successfully',
            'breeding_id': breeding_id,
            'expected_due_date': expected_due_date.date().isoformat()
        })
        
    except Exception as e:
        print(f"Breeding registration error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'Failed to register breeding: {str(e)}'})

@app.route('/api/breeding/list', methods=['GET'])
def get_breeding_records():
    """Get all breeding records with calculated status and days to farrowing"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all breeding records with pig and farm information
        cursor.execute("""
            SELECT br.*, 
                   sow.tag_id as sow_tag_id, sow.breed as sow_breed, sow.breeding_status,
                   boar.tag_id as boar_tag_id, boar.breed as boar_breed,
                   e.full_name as created_by_name
            FROM breeding_records br
            LEFT JOIN pigs sow ON br.sow_id = sow.id
            LEFT JOIN pigs boar ON br.boar_id = boar.id
            LEFT JOIN employees e ON br.created_by = e.id
            ORDER BY br.created_at DESC
        """)
        records = cursor.fetchall()
        
        # Process records using actual breeding status from pigs table
        from datetime import datetime
        today = datetime.now().date()
        
        # Auto-update breeding statuses based on time
        for record in records:
            if record['mating_date'] and record['breeding_status'] == 'served':
                mating_date = record['mating_date']
                days_since_mating = (today - mating_date).days
                
                # If more than 25 days have passed since mating, update to pregnant
                if days_since_mating > 25:
                    cursor.execute("""
                        UPDATE pigs 
                        SET breeding_status = 'pregnant' 
                        WHERE id = %s
                    """, (record['sow_id'],))
                    record['breeding_status'] = 'pregnant'
        
        processed_records = []
        for record in records:
            record_dict = dict(record)
            
            # Use the actual breeding_status from the pigs table
            breeding_status = record['breeding_status']
            record_dict['breeding_status'] = breeding_status
            
            # Calculate days to farrowing (pregnancy is 114 days)
            if record['mating_date']:
                mating_date = record['mating_date']
                days_since_mating = (today - mating_date).days
                days_to_farrowing = 114 - days_since_mating
                
                # Calculate expected due date (114 days from mating)
                from datetime import timedelta
                expected_due_date = mating_date + timedelta(days=114)
                record_dict['expected_due_date'] = expected_due_date
                
                # Determine if can cancel based on breeding status and days
                # Can only cancel within 25 days of mating (served status)
                days_since_mating = (datetime.now().date() - record['mating_date']).days
                if breeding_status == 'served' and days_since_mating <= 25:
                    record_dict['can_cancel'] = True
                    record_dict['days_remaining_to_cancel'] = 25 - days_since_mating
                elif breeding_status == 'pregnant':
                    record_dict['can_cancel'] = False
                    record_dict['days_remaining_to_cancel'] = 0
                else:
                    record_dict['can_cancel'] = False
                    record_dict['days_remaining_to_cancel'] = 0
                
                record_dict['days_to_farrowing'] = max(0, days_to_farrowing)
            else:
                record_dict['can_cancel'] = False
                record_dict['days_to_farrowing'] = None
                record_dict['expected_due_date'] = None
            
            processed_records.append(record_dict)
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'records': processed_records
        })
        
    except Exception as e:
        print(f"Error getting breeding records: {str(e)}")
        return jsonify({'error': str(e)}), 500


@app.route('/api/breeding/cancel/<int:breeding_id>', methods=['POST'])
def cancel_breeding(breeding_id):
    """Cancel a breeding record (within 93 days to farrowing)"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        reason = data.get('reason', 'No reason provided')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get breeding record
        cursor.execute("""
            SELECT br.*, sow.tag_id as sow_tag_id, sow.breeding_status
            FROM breeding_records br
            LEFT JOIN pigs sow ON br.sow_id = sow.id
            WHERE br.id = %s
        """, (breeding_id,))
        record = cursor.fetchone()
        
        if not record:
            return jsonify({'success': False, 'message': 'Breeding record not found'})
        
        # Check if within 25 days of mating
        from datetime import datetime
        mating_date = record['mating_date']
        days_since_mating = (datetime.now().date() - mating_date).days
        
        if days_since_mating > 25:  # More than 25 days since mating = pregnant
            return jsonify({'success': False, 'message': 'Cannot cancel breeding after 25 days from mating'})
        
        # Move breeding record to failed_conceptions table
        cursor.execute("""
            INSERT INTO failed_conceptions (sow_id, boar_id, mating_date, failure_date, failure_reason, notes, created_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (record['sow_id'], record['boar_id'], record['mating_date'], datetime.now().date(), reason, record['notes'] or '', session['employee_id']))
        
        # Remove the breeding record from breeding_records table
        cursor.execute("DELETE FROM breeding_records WHERE id = %s", (breeding_id,))
        
        # Update sow's breeding status back to available
        cursor.execute("""
            UPDATE pigs 
            SET breeding_status = 'available' 
            WHERE id = %s
        """, (record['sow_id'],))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        # Log activity
        log_activity(session['employee_id'], 'BREEDING_CANCELLATION', 
                    f'Breeding cancelled: Sow {record["sow_tag_id"]} - Reason: {reason}')
        
        return jsonify({
            'success': True,
            'message': 'Breeding record cancelled successfully'
        })
        
    except Exception as e:
        print(f"Breeding cancellation error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'Failed to cancel breeding: {str(e)}'})

@app.route('/api/breeding/failed-conceptions', methods=['GET'])
def get_failed_conceptions():
    """Get all failed conception records"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all failed conception records with pig and farm information
        cursor.execute("""
            SELECT fc.*, 
                   sow.tag_id as sow_tag_id, sow.breed as sow_breed,
                   boar.tag_id as boar_tag_id, boar.breed as boar_breed,
                   e.full_name as created_by_name
            FROM failed_conceptions fc
            LEFT JOIN pigs sow ON fc.sow_id = sow.id
            LEFT JOIN pigs boar ON fc.boar_id = boar.id
            LEFT JOIN employees e ON fc.created_by = e.id
            ORDER BY fc.created_at DESC
        """)
        records = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'records': records
        })
        
    except Exception as e:
        print(f"Error getting failed conceptions: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/breeding/completed-farrowings', methods=['GET'])
def get_completed_farrowings():
    """Get all completed farrowing records"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all completed farrowing records with pig and farm information
        # Only show pigs whose breeding status is 'farrowed'
        cursor.execute("""
            SELECT fr.*, 
                   br.mating_date,
                   sow.tag_id as sow_tag_id, sow.breed as sow_breed,
                   boar.tag_id as boar_tag_id, boar.breed as boar_breed,
                   e.full_name as created_by_name
            FROM farrowing_records fr
            JOIN breeding_records br ON fr.breeding_id = br.id
            LEFT JOIN pigs sow ON br.sow_id = sow.id
            LEFT JOIN pigs boar ON br.boar_id = boar.id
            LEFT JOIN employees e ON fr.created_by = e.id
            WHERE sow.breeding_status = 'farrowed'
            ORDER BY fr.farrowing_date DESC
        """)
        records = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'records': records
        })
        
    except Exception as e:
        print(f"Error getting completed farrowings: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/breeding/statistics', methods=['GET'])
def get_breeding_statistics():
    """Get breeding statistics including success and failure rates"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get breeding records count by status
        cursor.execute("""
            SELECT 
                COUNT(CASE WHEN status = 'served' THEN 1 END) as served_count,
                COUNT(CASE WHEN status = 'pregnant' THEN 1 END) as pregnant_count,
                COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled_count
            FROM breeding_records
        """)
        breeding_stats = cursor.fetchone()
        
        # Get failed conceptions count
        cursor.execute("SELECT COUNT(*) as failed_count FROM failed_conceptions")
        failed_count = cursor.fetchone()['failed_count']
        
        # Calculate success rate
        total_attempts = (breeding_stats['served_count'] or 0) + (breeding_stats['pregnant_count'] or 0) + failed_count
        success_rate = 0
        if total_attempts > 0:
            success_rate = round(((breeding_stats['pregnant_count'] or 0) / total_attempts) * 100, 2)
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'statistics': {
                'served_count': breeding_stats['served_count'] or 0,
                'pregnant_count': breeding_stats['pregnant_count'] or 0,
                'cancelled_count': breeding_stats['cancelled_count'] or 0,
                'failed_count': failed_count,
                'total_attempts': total_attempts,
                'success_rate': success_rate
            }
        })
        
    except Exception as e:
        print(f"Error getting breeding statistics: {str(e)}")
        return jsonify({'error': str(e)}), 500

def update_breeding_statuses():
    """Update breeding statuses based on time elapsed"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get breeding records that need status updates
        cursor.execute("""
            SELECT br.id, br.sow_id, br.mating_date, br.status, sow.tag_id
            FROM breeding_records br
            LEFT JOIN pigs sow ON br.sow_id = sow.id
            WHERE br.status = 'served'
        """)
        records = cursor.fetchall()
        
        from datetime import datetime
        today = datetime.now().date()
        updated_count = 0
        
        for record in records:
            days_since_mating = (today - record['mating_date']).days
            
            # If more than 25 days have passed, change status to pregnant
            if days_since_mating > 25:
                cursor.execute("""
                    UPDATE breeding_records 
                    SET status = 'pregnant' 
                    WHERE id = %s
                """, (record['id'],))
                
                # Update sow's breeding status to pregnant
                cursor.execute("""
                    UPDATE pigs 
                    SET breeding_status = 'pregnant' 
                    WHERE id = %s
                """, (record['sow_id'],))
                
                updated_count += 1
        
        conn.commit()
        cursor.close()
        conn.close()
        
        if updated_count > 0:
            print(f"✅ Updated {updated_count} breeding statuses to pregnant")
        
    except Exception as e:
        print(f"❌ Error updating breeding statuses: {e}")
        import traceback
        traceback.print_exc()

@app.route('/api/breeding/register-farrowing/<int:breeding_id>', methods=['POST'])
def register_farrowing(breeding_id):
    """Register farrowing for a breeding record"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        from datetime import timedelta
        data = request.get_json()
        farrowing_date = data.get('farrowing_date')
        alive_piglets = data.get('alive_piglets')
        still_births = data.get('still_births')
        avg_weight = data.get('avg_weight')
        health_notes = data.get('health_notes', '')
        
        if not all([farrowing_date, alive_piglets is not None, still_births is not None, avg_weight is not None]):
            return jsonify({'success': False, 'message': 'Missing required fields'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get breeding record details
        cursor.execute("""
            SELECT br.*, p.tag_id as sow_tag_id, p.breed as sow_breed
            FROM breeding_records br
            JOIN pigs p ON br.sow_id = p.id
            WHERE br.id = %s
        """, (breeding_id,))
        
        breeding_record = cursor.fetchone()
        if not breeding_record:
            return jsonify({'success': False, 'message': 'Breeding record not found'})
        
        # Insert farrowing record
        cursor.execute("""
            INSERT INTO farrowing_records (
                breeding_id, farrowing_date, alive_piglets, still_births, 
                avg_weight, health_notes, created_by
            ) VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (
            breeding_id, farrowing_date, alive_piglets, still_births,
            avg_weight, health_notes, session['employee_id']
        ))
        
        farrowing_id = cursor.lastrowid
        
        # Create farrowing activities with due dates
        activities = [
            (1, 'Clear airways, ensure colostrum intake'),
            (1, 'Provide heat lamps'),
            (1, 'Remove afterbirth'),
            (2, 'Iron injections'),
            (2, 'Ear notching/tagging'),
            (3, 'Tail docking'),
            (3, 'Castration (males)'),
            (14, 'Start creep feed'),
            (21, 'Weaning')
        ]
        
        for due_day, activity_name in activities:
            # Convert farrowing_date string to date object for timedelta calculation
            farrowing_date_obj = datetime.strptime(farrowing_date, '%Y-%m-%d').date()
            due_date = farrowing_date_obj + timedelta(days=due_day)
            cursor.execute("""
                INSERT INTO farrowing_activities (
                    farrowing_record_id, activity_name, due_day, due_date
                ) VALUES (%s, %s, %s, %s)
            """, (farrowing_id, activity_name, due_day, due_date))
        
        # Update breeding record status to completed
        print(f"Updating breeding record {breeding_id} status to 'completed'")
        cursor.execute("""
            UPDATE breeding_records 
            SET status = 'completed', updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """, (breeding_id,))
        
        # Create litter record
        litter_id = generate_litter_id()
        total_piglets = alive_piglets + still_births
        
        cursor.execute("""
            INSERT INTO litters (
                litter_id, farrowing_record_id, sow_id, boar_id, farrowing_date,
                total_piglets, alive_piglets, still_births, avg_weight, created_by
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """, (
            litter_id, farrowing_id, breeding_record['sow_id'], breeding_record['boar_id'],
            farrowing_date, total_piglets, alive_piglets, still_births, avg_weight, session['employee_id']
        ))
        
        print(f"📝 Created litter record: {litter_id}")
        
        # Update sow's breeding status to farrowed
        print(f"Updating sow {breeding_record['sow_id']} breeding status to 'farrowed'")
        # Note: Sows with 'farrowed' status need recovery time before being bred again
        # This status can be manually changed back to 'available' by farm managers
        # or automatically after a set recovery period (typically 2-3 months)
        cursor.execute("""
            UPDATE pigs 
            SET breeding_status = 'farrowed' 
            WHERE id = %s
        """, (breeding_record['sow_id'],))
        
        # Verify the updates
        cursor.execute("SELECT status FROM breeding_records WHERE id = %s", (breeding_id,))
        updated_breeding = cursor.fetchone()
        print(f"✅ Breeding record status after update: {updated_breeding['status']}")
        
        cursor.execute("SELECT breeding_status FROM pigs WHERE id = %s", (breeding_record['sow_id'],))
        updated_pig = cursor.fetchone()
        print(f"✅ Pig breeding status after update: {updated_pig['breeding_status']}")
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print(f"Farrowing registration completed successfully for breeding record {breeding_id}")
        
        return jsonify({
            'success': True,
            'message': 'Farrowing registered successfully'
        })
        
    except Exception as e:
        print(f"Farrowing registration error: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': f'Failed to register farrowing: {str(e)}'})

@app.route('/api/farrowing/activities/<int:farrowing_id>', methods=['GET'])
def get_farrowing_activities(farrowing_id):
    """Get farrowing activities for a specific farrowing record"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get farrowing activities with completion status
        cursor.execute("""
            SELECT fa.*, e.full_name as completed_by_name
            FROM farrowing_activities fa
            LEFT JOIN employees e ON fa.completed_by = e.id
            WHERE fa.farrowing_record_id = %s
            ORDER BY fa.due_day ASC
        """, (farrowing_id,))
        
        activities = cursor.fetchall()
        
        # Auto-complete activities that have reached their exact due day
        today = datetime.now().date()
        for activity in activities:
            if not activity['completed'] and activity['due_date'] == today:
                cursor.execute("""
                    UPDATE farrowing_activities 
                    SET completed = TRUE, completed_date = %s, 
                        notes = CONCAT(COALESCE(notes, ''), ' - Auto-completed on due day ', %s)
                    WHERE id = %s
                """, (today, today, activity['id']))
                activity['completed'] = True
                activity['completed_date'] = today
                activity['notes'] = f"Auto-completed on due day {today}"
        
        # Refresh activities after auto-completion
        if any(not a['completed'] and a['due_date'] == today for a in activities):
            cursor.execute("""
                SELECT fa.*, e.full_name as completed_by_name
                FROM farrowing_activities fa
                LEFT JOIN employees e ON fa.completed_by = e.id
                WHERE fa.farrowing_record_id = %s
                ORDER BY fa.due_day ASC
            """, (farrowing_id,))
            activities = cursor.fetchall()
        
        # Convert to list of dictionaries
        activities_list = []
        for activity in activities:
            activities_list.append({
                'id': activity['id'],
                'activity_name': activity['activity_name'],
                'due_day': activity['due_day'],
                'due_date': activity['due_date'].isoformat() if activity['due_date'] else None,
                'completed': bool(activity['completed']),
                'completed_date': activity['completed_date'].isoformat() if activity['completed_date'] else None,
                'completed_by': activity['completed_by_name'],
                'notes': activity['notes'],
                'weaning_weight': float(activity['weaning_weight']) if activity['weaning_weight'] else None,
                'weaning_date': activity['weaning_date'].isoformat() if activity['weaning_date'] else None
            })
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'activities': activities_list
        })
        
    except Exception as e:
        print(f"Error getting farrowing activities: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get activities: {str(e)}'})

@app.route('/api/farrowing/activities/<int:activity_id>/complete', methods=['POST'])
def complete_farrowing_activity(activity_id):
    """Mark a farrowing activity as completed"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        notes = data.get('notes', '')
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # First, get the activity details to check if it can be completed
        cursor.execute("""
            SELECT fa.*, fr.farrowing_date 
            FROM farrowing_activities fa
            JOIN farrowing_records fr ON fa.farrowing_record_id = fr.id
            WHERE fa.id = %s
        """, (activity_id,))
        
        activity = cursor.fetchone()
        if not activity:
            return jsonify({'success': False, 'message': 'Activity not found'})
        
        # Check if the activity is already completed
        if activity['completed']:
            return jsonify({'success': False, 'message': 'Activity is already completed'})
        
        # Check if the current date has reached the activity day
        from datetime import datetime, timedelta
        today = datetime.now().date()
        farrowing_date = activity['farrowing_date']
        activity_day = activity['due_day']
        due_date = farrowing_date + timedelta(days=activity_day)
        
        if today < due_date:
            return jsonify({
                'success': False, 
                'message': f'Cannot complete activity before Day {activity_day}. This activity is due on {due_date.strftime("%Y-%m-%d")}'
            })
        
        # Check if activity is overdue and add warning
        is_overdue = today > due_date
        overdue_warning = ""
        if is_overdue:
            days_overdue = (today - due_date).days
            overdue_warning = f" (Note: This activity is {days_overdue} day(s) overdue)"
        
        # Check if this is a weaning activity and requires additional data
        weaning_weight = None
        weaning_date = None
        
        if activity['activity_name'] == 'Weaning':
            weaning_weight = data.get('weaning_weight')
            weaning_date = data.get('weaning_date')
            
            if not weaning_weight:
                return jsonify({'success': False, 'message': 'Weaning weight is required for weaning activity'})
            
            if not weaning_date:
                return jsonify({'success': False, 'message': 'Weaning date and time is required for weaning activity'})
        
        # Mark activity as completed
        cursor.execute("""
            UPDATE farrowing_activities 
            SET completed = TRUE, completed_date = CURRENT_DATE, 
                completed_by = %s, notes = %s, weaning_weight = %s, weaning_date = %s, updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """, (session['employee_id'], notes, weaning_weight, weaning_date, activity_id))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        # Log activity
        log_activity(session['employee_id'], 'FARROWING_ACTIVITY_COMPLETED', 
                    f'Completed farrowing activity ID {activity_id} on {today}')
        
        # Check if all activities are completed and trigger recovery period
        if is_overdue:
            check_and_trigger_recovery_period(activity['farrowing_record_id'])
        
        return jsonify({
            'success': True,
            'message': f'Activity "Day {activity_day}: {activity["activity_name"]}" marked as completed{overdue_warning}'
        })
        
    except Exception as e:
        print(f"Error completing farrowing activity: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to complete activity: {str(e)}'})

@app.route('/api/farrowing/complete-activity/<int:activity_id>', methods=['POST'])
def complete_farrowing_activity_simple(activity_id):
    """Simple complete farrowing activity endpoint for compatibility"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Update the activity as completed
        cursor.execute("""
            UPDATE farrowing_activities 
            SET completed = TRUE, completed_date = NOW() 
            WHERE id = %s
        """, (activity_id,))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': 'Activity completed successfully'
        })
        
    except Exception as e:
        print(f"Error completing farrowing activity: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/farrowing/check-recovery/<int:farrowing_id>', methods=['GET'])
def check_sow_recovery_status(farrowing_id):
    """Check if sow is ready for next breeding (40 days after farrowing)"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get farrowing details and calculate recovery status
        cursor.execute("""
            SELECT fr.farrowing_date, fr.id, br.sow_id, p.tag_id as sow_tag_id,
                   p.breeding_status, p.breed
            FROM farrowing_records fr
            JOIN breeding_records br ON fr.breeding_id = br.id
            JOIN pigs p ON br.sow_id = p.id
            WHERE fr.id = %s
        """, (farrowing_id,))
        
        farrowing = cursor.fetchone()
        if not farrowing:
            return jsonify({'success': False, 'message': 'Farrowing record not found'})
        
        from datetime import datetime, timedelta
        today = datetime.now().date()
        farrowing_date = farrowing['farrowing_date']
        recovery_date = farrowing_date + timedelta(days=40)
        days_until_recovery = (recovery_date - today).days
        
        # Check if all activities are completed
        cursor.execute("""
            SELECT COUNT(*) as total_activities,
                   SUM(CASE WHEN completed = TRUE THEN 1 ELSE 0 END) as completed_activities
            FROM farrowing_activities 
            WHERE farrowing_record_id = %s
        """, (farrowing_id,))
        
        activities_result = cursor.fetchone()
        all_activities_completed = activities_result['total_activities'] == activities_result['completed_activities']
        
        # Check if sow is ready for next breeding
        sow_ready = today >= recovery_date and all_activities_completed
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'data': {
                'farrowing_date': farrowing_date.isoformat(),
                'recovery_date': recovery_date.isoformat(),
                'days_until_recovery': max(0, days_until_recovery),
                'all_activities_completed': all_activities_completed,
                'sow_ready': sow_ready,
                'sow_tag_id': farrowing['sow_tag_id'],
                'current_breeding_status': farrowing['breeding_status'],
                'sow_breed': farrowing['breed']
            }
        })
        
    except Exception as e:
        print(f"Error checking sow recovery status: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to check recovery status: {str(e)}'})

@app.route('/api/farrowing/mark-sow-available/<int:farrowing_id>', methods=['POST'])
def mark_sow_available_for_breeding(farrowing_id):
    """Mark sow as available for next breeding after recovery period"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get farrowing details
        cursor.execute("""
            SELECT fr.farrowing_date, fr.id, br.sow_id, br.id as breeding_id, p.tag_id as sow_tag_id
            FROM farrowing_records fr
            JOIN breeding_records br ON fr.breeding_id = br.id
            JOIN pigs p ON br.sow_id = p.id
            WHERE fr.id = %s
        """, (farrowing_id,))
        
        farrowing = cursor.fetchone()
        if not farrowing:
            return jsonify({'success': False, 'message': 'Farrowing record not found'})
        
        # Check if recovery period is complete
        from datetime import datetime, timedelta
        today = datetime.now().date()
        farrowing_date = farrowing['farrowing_date']
        recovery_date = farrowing_date + timedelta(days=40)
        
        if today < recovery_date:
            return jsonify({
                'success': False, 
                'message': f'Sow is not ready yet. Recovery period ends on {recovery_date.strftime("%Y-%m-%d")}'
            })
        
        # Check if all activities are completed
        cursor.execute("""
            SELECT COUNT(*) as total_activities,
                   SUM(CASE WHEN completed = TRUE THEN 1 ELSE 0 END) as completed_activities
            FROM farrowing_activities 
            WHERE farrowing_record_id = %s
        """, (farrowing_id,))
        
        activities_result = cursor.fetchone()
        if activities_result['total_activities'] != activities_result['completed_activities']:
            return jsonify({
                'success': False, 
                'message': 'Cannot mark sow as available until all farrowing activities are completed'
            })

        # Check if weaning activity is completed and update litter status
        cursor.execute("""
            SELECT fa.*, l.id as litter_id
            FROM farrowing_activities fa
            JOIN litters l ON l.farrowing_record_id = fa.farrowing_record_id
            WHERE fa.farrowing_record_id = %s AND fa.activity_name = 'Weaning'
        """, (farrowing_id,))
        
        weaning_activity = cursor.fetchone()
        if weaning_activity and weaning_activity['completed']:
            # Update litter status to weaned
            cursor.execute("""
                UPDATE litters 
                SET status = 'weaned', weaning_date = %s, weaning_weight = %s, updated_at = CURRENT_TIMESTAMP
                WHERE id = %s
            """, (weaning_activity['weaning_date'], weaning_activity['weaning_weight'], weaning_activity['litter_id']))
            print(f"✅ Updated litter {weaning_activity['litter_id']} status to 'weaned'")
        else:
            # Check which activities are not completed
            cursor.execute("""
                SELECT activity_name, due_day, due_date
                FROM farrowing_activities 
                WHERE farrowing_record_id = %s AND completed = FALSE
                ORDER BY due_day ASC
            """, (farrowing_id,))
            
            incomplete_activities = cursor.fetchall()
            if incomplete_activities:
                incomplete_list = [f"Day {activity['due_day']}: {activity['activity_name']}" for activity in incomplete_activities]
                return jsonify({
                    'success': False, 
                    'message': 'Cannot mark sow as available. Incomplete farrowing activities:',
                    'incomplete_activities': incomplete_list
                })
        
        # Check if litter registration is required
        cursor.execute("""
            SELECT COUNT(*) as litter_count
            FROM litters 
            WHERE farrowing_record_id = %s
        """, (farrowing_id,))
        
        litter_result = cursor.fetchone()
        if litter_result['litter_count'] == 0:
            # Litter registration is required before marking sow as available
            return jsonify({
                'success': False, 
                'message': 'Litter registration required',
                'requires_litter_registration': True,
                'farrowing_data': {
                    'farrowing_id': farrowing_id,
                    'breeding_id': farrowing['breeding_id'],
                    'sow_id': farrowing['sow_id'],
                    'sow_tag_id': farrowing['sow_tag_id'],
                    'farrowing_date': farrowing['farrowing_date'].strftime('%Y-%m-%d')
                }
            })
        
        # Update sow's breeding status to available
        cursor.execute("""
            UPDATE pigs 
            SET breeding_status = 'available' 
            WHERE id = %s
        """, (farrowing['sow_id'],))
        
        # Log the successful breeding cycle completion
        log_activity(session['employee_id'], 'BREEDING_CYCLE_COMPLETED', 
                    f'Successful breeding cycle completed for sow {farrowing["sow_tag_id"]}. Ready for next breeding.')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Sow {farrowing["sow_tag_id"]} marked as available for next breeding. Successful breeding cycle completed!'
        })
        
    except Exception as e:
        print(f"Error marking sow as available: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to mark sow as available: {str(e)}'})

@app.route('/api/farrowing/litter-registration-data/<int:farrowing_id>', methods=['GET'])
def get_farrowing_litter_registration_data(farrowing_id):
    """Get farrowing data needed for litter registration"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get comprehensive farrowing data for litter registration
        cursor.execute("""
            SELECT fr.*, 
                   br.mating_date, br.expected_due_date,
                   sow.tag_id as sow_tag_id, sow.breed as sow_breed, sow.age_days as sow_age_days,
                   sow.farm_id as sow_farm_id, f.farm_name as sow_farm_name,
                   boar.tag_id as boar_tag_id, boar.breed as boar_breed,
                   e.full_name as created_by_name
            FROM farrowing_records fr
            JOIN breeding_records br ON fr.breeding_id = br.id
            LEFT JOIN pigs sow ON br.sow_id = sow.id
            LEFT JOIN pigs boar ON br.boar_id = boar.id
            LEFT JOIN farms f ON sow.farm_id = f.id
            LEFT JOIN employees e ON fr.created_by = e.id
            WHERE fr.id = %s
        """, (farrowing_id,))
        
        farrowing_data = cursor.fetchone()
        if not farrowing_data:
            return jsonify({'success': False, 'message': 'Farrowing record not found'})
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'farrowing_data': farrowing_data
        })
        
    except Exception as e:
        print(f"Error getting farrowing litter registration data: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get farrowing data: {str(e)}'})

@app.route('/api/farrowing/active-litters', methods=['GET'])
def get_farrowing_active_litters():
    """Get all active litters (alias for /api/litter/active)"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get unweaned litters with sow information
        cursor.execute("""
            SELECT l.*, 
                   p.tag_id as sow_tag_id, p.breed as sow_breed,
                   f.farm_name as farm_name
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            LEFT JOIN farms f ON p.farm_id = f.id
            WHERE l.status = 'unweaned'
            ORDER BY l.farrowing_date DESC
        """)
        
        litters = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'litters': litters
        })
        
    except Exception as e:
        print(f"Error getting active litters: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get active litters: {str(e)}'})

@app.route('/api/farrowing/weaned-litters', methods=['GET'])
def get_farrowing_weaned_litters():
    """Get all weaned litters (alias for /api/litter/weaned)"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get weaned litters with sow information
        cursor.execute("""
            SELECT l.*, 
                   p.tag_id as sow_tag_id, p.breed as sow_breed,
                   f.farm_name as farm_name
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            LEFT JOIN farms f ON p.farm_id = f.id
            WHERE l.status = 'weaned'
            ORDER BY l.weaning_date DESC
        """)
        
        litters = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'litters': litters
        })
        
    except Exception as e:
        print(f"Error getting weaned litters: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get weaned litters: {str(e)}'})

@app.route('/api/litter/active', methods=['GET'])
def get_active_litters():
    """Get all active litters"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get unweaned litters with sow information
        cursor.execute("""
            SELECT l.*, 
                   p.tag_id as sow_tag_id, p.breed as sow_breed,
                   f.farm_name as farm_name
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            LEFT JOIN farms f ON p.farm_id = f.id
            WHERE l.status = 'unweaned'
            ORDER BY l.farrowing_date DESC
        """)
        
        litters = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'litters': litters
        })
        
    except Exception as e:
        print(f"Error getting active litters: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get active litters: {str(e)}'})

@app.route('/api/litter/<litter_id>/wean', methods=['POST'])
def mark_litter_weaned(litter_id):
    """Mark a litter as weaned"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get litter details
        cursor.execute("""
            SELECT l.*, p.tag_id as sow_tag_id
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            WHERE l.litter_id = %s
        """, (litter_id,))
        
        litter = cursor.fetchone()
        if not litter:
            return jsonify({'success': False, 'message': 'Litter not found'})
        
        # Check if litter is already weaned
        if litter['weaning_date']:
            return jsonify({'success': False, 'message': 'Litter is already marked as weaned'})
        
        # Check if all farrowing activities are completed
        cursor.execute("""
            SELECT COUNT(*) as total_activities,
                   SUM(CASE WHEN completed = TRUE THEN 1 ELSE 0 END) as completed_activities
            FROM farrowing_activities fa
            JOIN litters l ON l.farrowing_record_id = fa.farrowing_record_id
            WHERE l.litter_id = %s
        """, (litter_id,))
        
        activities_result = cursor.fetchone()
        if activities_result['total_activities'] != activities_result['completed_activities']:
            return jsonify({
                'success': False, 
                'message': 'Cannot mark litter as weaned until all farrowing activities are completed'
            })
        
        # Update litter status to weaned
        cursor.execute("""
            UPDATE litters 
            SET status = 'weaned', updated_at = CURRENT_TIMESTAMP
            WHERE litter_id = %s
        """, (litter_id,))
        
        # Log activity
        log_activity(session['employee_id'], 'LITTER_WEANED', 
                    f'Marked litter {litter_id} as weaned for sow {litter["sow_tag_id"]}')
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Litter {litter_id} marked as weaned successfully'
        })
        
    except Exception as e:
        print(f"Error marking litter as weaned: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to mark litter as weaned: {str(e)}'})

@app.route('/api/litter/weaned', methods=['GET'])
def get_weaned_litters():
    """Get all weaned litters"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get weaned litters with sow information
        cursor.execute("""
            SELECT l.*, 
                   p.tag_id as sow_tag_id, p.breed as sow_breed,
                   f.farm_name as farm_name
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            LEFT JOIN farms f ON p.farm_id = f.id
            WHERE l.status = 'weaned'
            ORDER BY l.weaning_date DESC
        """)
        
        litters = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'litters': litters
        })
        
    except Exception as e:
        print(f"Error getting weaned litters: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get weaned litters: {str(e)}'})

@app.route('/api/litter/all', methods=['GET'])
def get_all_litters():
    """Get all litters (both unweaned and weaned)"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all litters with sow information
        cursor.execute("""
            SELECT l.*, 
                   p.tag_id as sow_tag_id, p.breed as sow_breed,
                   f.farm_name as farm_name
            FROM litters l
            LEFT JOIN pigs p ON l.sow_id = p.id
            LEFT JOIN farms f ON p.farm_id = f.id
            ORDER BY l.farrowing_date DESC
        """)
        
        litters = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'litters': litters
        })
        
    except Exception as e:
        print(f"Error getting all litters: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get all litters: {str(e)}'})

@app.route('/api/litter/check-id/<litter_id>', methods=['GET'])
def check_litter_id(litter_id):
    """Check if a litter ID already exists"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get exclude parameter if provided
        exclude_id = request.args.get('exclude', None)
        
        # Check if litter ID exists
        if exclude_id:
            cursor.execute("SELECT id FROM litters WHERE litter_id = %s AND id != %s", (litter_id, exclude_id))
        else:
            cursor.execute("SELECT id FROM litters WHERE litter_id = %s", (litter_id,))
        
        existing_litter = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        return jsonify({
            'exists': existing_litter is not None
        })
        
    except Exception as e:
        print(f"Error checking litter ID: {str(e)}")
        return jsonify({'exists': False, 'error': str(e)})

@app.route('/api/litter/update/<int:litter_id>', methods=['PUT'])
def update_litter(litter_id):
    """Update litter details"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['litter_id', 'sow_id', 'farrowing_date', 'alive_piglets', 'status']
        for field in required_fields:
            if field not in data or data[field] is None:
                return jsonify({'success': False, 'message': f'Missing required field: {field}'})
        
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if litter exists
        cursor.execute("SELECT * FROM litters WHERE id = %s", (litter_id,))
        existing_litter = cursor.fetchone()
        
        if not existing_litter:
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Litter not found'})
        
        # Check if new litter_id already exists (excluding current litter)
        if data['litter_id'] != existing_litter['litter_id']:
            cursor.execute("SELECT id FROM litters WHERE litter_id = %s AND id != %s", (data['litter_id'], litter_id))
            if cursor.fetchone():
                cursor.close()
                conn.close()
                return jsonify({'success': False, 'message': 'Litter ID already exists'})
        
        # Validate farrowing date is not in the future
        farrowing_date = datetime.strptime(data['farrowing_date'], '%Y-%m-%d').date()
        if farrowing_date > datetime.now().date():
            cursor.close()
            conn.close()
            return jsonify({'success': False, 'message': 'Farrowing date cannot be in the future'})
        
        # Validate weaning date if provided
        weaning_date = None
        if data.get('weaning_date'):
            weaning_date = datetime.strptime(data['weaning_date'], '%Y-%m-%d').date()
            if weaning_date < farrowing_date:
                cursor.close()
                conn.close()
                return jsonify({'success': False, 'message': 'Weaning date cannot be before farrowing date'})
        
        # Prepare the new litter ID with "E" prefix if it's being changed
        new_litter_id = data['litter_id']
        if new_litter_id != existing_litter['litter_id'] and not new_litter_id.startswith('E'):
            new_litter_id = f"E{data['litter_id']}"
        
        # Update the litter
        update_query = """
            UPDATE litters 
            SET litter_id = %s, sow_id = %s, farrowing_date = %s, 
                weaning_date = %s, alive_piglets = %s, weaning_weight = %s, 
                status = %s, updated_at = NOW()
            WHERE id = %s
        """
        
        cursor.execute(update_query, (
            new_litter_id,
            data['sow_id'],
            data['farrowing_date'],
            data.get('weaning_date'),
            data['alive_piglets'],
            data.get('weaning_weight'),
            data['status'],
            litter_id
        ))
        
        # Log the activity
        activity_description = f"Litter details updated: ID changed to {new_litter_id}, Sow: {data['sow_id']}, Farrowing: {data['farrowing_date']}, Alive piglets: {data['alive_piglets']}, Status: {data['status']}"
        
        cursor.execute("""
            INSERT INTO litter_activities (litter_id, activity_type, description, created_at)
            VALUES (%s, %s, %s, NOW())
        """, (litter_id, 'updated', activity_description))
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Litter {new_litter_id} updated successfully',
            'litter_id': new_litter_id
        })
        
    except Exception as e:
        print(f"Error updating litter: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to update litter: {str(e)}'})

@app.route('/api/litter/<litter_id>/activities', methods=['GET'])
def get_litter_activities(litter_id):
    """Get all activities for a specific litter"""
    if 'employee_id' not in session or session.get('employee_role') != 'administrator':
        return jsonify({'error': 'Unauthorized'}), 401
    
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        print(f"🔍 Looking for litter: {litter_id}")
        
        # First, check if the litter exists
        cursor.execute("SELECT * FROM litters WHERE litter_id = %s", (litter_id,))
        litter_check = cursor.fetchone()
        
        if not litter_check:
            print(f"❌ Litter {litter_id} not found in litters table")
            return jsonify({'success': False, 'message': f'Litter {litter_id} not found in database'})
        
        print(f"✅ Found litter: {litter_check}")
        
        # Check if there's a farrowing record
        if not litter_check.get('farrowing_record_id'):
            print(f"❌ Litter {litter_id} has no farrowing_record_id")
            return jsonify({'success': False, 'message': f'Litter {litter_id} has no associated farrowing record'})
        
        # Get farrowing record details
        cursor.execute("""
            SELECT fr.*
            FROM farrowing_records fr
            WHERE fr.id = %s
        """, (litter_check['farrowing_record_id'],))
        
        farrowing_record = cursor.fetchone()
        if not farrowing_record:
            print(f"❌ Farrowing record {litter_check['farrowing_record_id']} not found")
            return jsonify({'success': False, 'message': f'Farrowing record not found for litter {litter_id}'})
        
        print(f"✅ Found farrowing record: {farrowing_record}")
        
        # Use litter_check instead of litter
        litter = litter_check
        
        # Get all farrowing activities for this litter
        cursor.execute("""
            SELECT fa.*, 
                   CASE 
                       WHEN fa.completed = TRUE THEN 'Completed'
                       WHEN fa.due_date < CURRENT_DATE THEN 'Overdue'
                       WHEN fa.due_date = CURRENT_DATE THEN 'Due Today'
                       ELSE 'Upcoming'
                   END as status_category
            FROM farrowing_activities fa
            WHERE fa.farrowing_record_id = %s
            ORDER BY fa.due_day ASC
        """, (litter['farrowing_record_id'],))
        
        activities = cursor.fetchall()
        
        print(f"✅ Found {len(activities)} activities for litter {litter_id} (farrowing_record_id: {litter['farrowing_record_id']})")
        
        # Get sow information from the litter record BEFORE closing cursor
        cursor.execute("""
            SELECT p.tag_id as sow_tag_id
            FROM pigs p
            WHERE p.id = %s
        """, (litter_check['sow_id'],))
        
        sow_info = cursor.fetchone()
        sow_tag_id = sow_info['sow_tag_id'] if sow_info else 'N/A'
        
        cursor.close()
        conn.close()
        
        # Combine litter and farrowing data
        litter_data = {
            'id': litter_check['id'],
            'litter_id': litter_check['litter_id'],
            'farrowing_record_id': litter_check['farrowing_record_id'],
            'sow_id': litter_check['sow_id'],
            'farrowing_date': litter_check['farrowing_date'],
            'alive_piglets': litter_check['alive_piglets'],
            'status': litter_check['status'],
            'sow_tag_id': sow_tag_id
        }
        
        return jsonify({
            'success': True,
            'activities': activities,
            'litter': litter_data
        })
        
    except Exception as e:
        print(f"Error getting litter activities: {str(e)}")
        return jsonify({'success': False, 'message': f'Failed to get litter activities: {str(e)}'})

def check_and_trigger_recovery_period(farrowing_record_id):
    """Check if all farrowing activities are completed and trigger 40-day recovery period"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Check if all activities for this farrowing are completed
        cursor.execute("""
            SELECT COUNT(*) as total_activities,
                   SUM(CASE WHEN completed = TRUE THEN 1 ELSE 0 END) as completed_activities
            FROM farrowing_activities 
            WHERE farrowing_record_id = %s
        """, (farrowing_record_id,))
        
        result = cursor.fetchone()
        if result['total_activities'] == result['completed_activities'] and result['total_activities'] > 0:
            print(f"All activities completed for farrowing {farrowing_record_id}, starting 40-day recovery period")
            
            # Get farrowing details
            cursor.execute("""
                SELECT fr.farrowing_date, fr.id, br.sow_id
                FROM farrowing_records fr
                JOIN breeding_records br ON fr.breeding_id = br.id
                WHERE fr.id = %s
            """, (farrowing_record_id,))
            
            farrowing = cursor.fetchone()
            if farrowing:
                # Calculate recovery date (40 days from farrowing)
                from datetime import timedelta
                recovery_date = farrowing['farrowing_date'] + timedelta(days=40)
                
                # Log the recovery period start
                log_activity(session.get('employee_id', 1), 'RECOVERY_PERIOD_STARTED', 
                           f'40-day recovery period started for farrowing {farrowing_record_id}, sow ready on {recovery_date}')
                
                print(f"📅 Sow will be ready for next breeding on: {recovery_date}")
        
        cursor.close()
        conn.close()
        
    except Exception as e:
        print(f"Error checking recovery period: {str(e)}")

@app.route('/api/logout', methods=['POST'])
def api_logout():
    if 'employee_id' in session:
        # Log logout activity
        log_activity(session['employee_id'], 'LOGOUT', f'Employee {session["employee_name"]} logged out')
        session.clear()
    return {'success': True, 'redirect': url_for('landing')}

@app.route('/admin/farm/breeding-records')
def breeding_records_page():
    """Breeding Records page - Active breeding records only"""
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    if session.get('employee_role') != 'administrator':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_farm_breeding_records.html')

@app.route('/admin/farm/litters')
def admin_farm_litters():
    """Admin farm litters management page"""
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    if session.get('employee_role') != 'administrator':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_farm_litters.html')

@app.route('/admin/farm/failed-conceptions')
def failed_conceptions_page():
    """Failed Conceptions page - Failed breeding attempts only"""
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    if session.get('employee_role') != 'administrator':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_farm_failed_conceptions.html')

@app.route('/admin/farm/completed-farrowings')
def completed_farrowings_page():
    """Completed Farrowings page - Successful farrowings only"""
    if 'employee_id' not in session:
        return redirect(url_for('employee_login'))
    
    if session.get('employee_role') != 'administrator':
        flash('Access denied. Administrator privileges required.', 'error')
        return redirect(url_for('admin_dashboard'))
    
    return render_template('admin_farm_completed_farrowings.html')

if __name__ == '__main__':
    print("Starting Pig Farm Management System...")
    print("Checking database and tables...")
    
    # Create database and tables on startup
    if create_database_and_tables():
        print("✅ Database setup completed. Starting Flask application...")
        app.run(debug=True)
    else:
        print("❌ Failed to setup database. Please check your MySQL connection.")
        print("Make sure MySQL is running and the credentials are correct.")
